#!/bin/bash
# Full synthetic-clutter pipeline, resumable (each step leaves a .done marker).  Start with:
#   cd ~/projects/r1_revision && nohup setsid bash run_clutter_all.sh >> clutter_work/pipeline.log 2>&1 &
cd "$(dirname "$0")"
export CLUTTER_WORK=$HOME/projects/r1_revision/clutter_work
SYNC="/mnt/e/paper chat/clutter"
PYT=$HOME/miniconda3/envs/p310torch27/bin/python
PYY=$HOME/miniconda3/envs/ultralytics_yolo/bin/python
export HF_ENDPOINT=https://hf-mirror.com
mkdir -p "$CLUTTER_WORK" "$SYNC"
status() { echo "$(date '+%F %T') $*"; echo "$(date '+%F %T') $*" > "$CLUTTER_WORK/STATUS.txt"; cp "$CLUTTER_WORK/STATUS.txt" "$SYNC/STATUS.txt" 2>/dev/null; }
fail() { status "FAILED at step: $1 (see clutter_work/pipeline.log)"; cp "$CLUTTER_WORK/pipeline.log" "$SYNC/" 2>/dev/null; exit 1; }
cp "/mnt/e/paper chat/CAM/qc_exclude.txt" "$CLUTTER_WORK/qc_exclude.txt" 2>/dev/null

if [ ! -f "$CLUTTER_WORK/bg.done" ]; then
  status "step 1/5: downloading Places365 backgrounds"
  $PYY -u -m clutter.fetch_bg || fail "fetch_bg"
  touch "$CLUTTER_WORK/bg.done"
fi
if [ ! -f "$CLUTTER_WORK/masks.done" ]; then
  status "step 2/5: DINO+SAM masks for all TrashNet images (2 GPUs)"
  CUDA_VISIBLE_DEVICES=0 $PYY -u -m clutter.mask_tn --shard 0/2 > "$CLUTTER_WORK/mask0.log" 2>&1 &
  P0=$!
  CUDA_VISIBLE_DEVICES=1 $PYY -u -m clutter.mask_tn --shard 1/2 > "$CLUTTER_WORK/mask1.log" 2>&1 &
  P1=$!
  wait $P0 || fail "mask shard 0"
  wait $P1 || fail "mask shard 1"
  touch "$CLUTTER_WORK/masks.done"
fi
if [ ! -f "$CLUTTER_WORK/comp.done" ]; then
  status "step 3/5: compositing plain/rand/corr/conf"
  $PYY -u -m clutter.composite || fail "composite"
  $PYY -u -m clutter.qc_sheet "$SYNC/qc" || echo "qc sheet failed (non-fatal)"
  cp "$CLUTTER_WORK/comp/meta.csv" "$SYNC/comp_meta.csv" 2>/dev/null
  touch "$CLUTTER_WORK/comp.done"
fi
if [ ! -f "$CLUTTER_WORK/smoke.done" ]; then
  status "step 4/5: smoke test (R18 + D4 + C8, 1 epoch)"
  for p in R18 D4 C8; do
    CUDA_VISIBLE_DEVICES=0 $PYT -u -m clutter.run_clutter --arm corr --probe $p --seed 42 --epochs 1 \
      --limit-batches 3 --no-ckpt --out "$CLUTTER_WORK/smoke" || fail "smoke $p"
  done
  touch "$CLUTTER_WORK/smoke.done"
fi
status "step 5/5: training queue started"
$PYT -u -m clutter.launch_clutter --tiers 1,2 --gpus 0,1 --per-gpu 4 --workers 4
cp "$CLUTTER_WORK/pipeline.log" "$SYNC/" 2>/dev/null
N=$(ls "$CLUTTER_WORK"/results/*.json 2>/dev/null | wc -l)
status "ALL DONE: $N/45 runs finished. Results in E:\\paper chat\\clutter\\results"
