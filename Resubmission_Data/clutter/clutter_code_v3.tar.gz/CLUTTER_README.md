# 合成杂乱背景因果实验（Feature Purity Hypothesis 的干预检验）

启动（WSL，在 ~/projects/r1_revision 下）：
    tar xzf "/mnt/e/paper chat/clutter/clutter_code_v2.tar.gz"
    nohup setsid bash run_clutter_all.sh >> clutter_work/pipeline.log 2>&1 &

可随时查看进度：E:\paper chat\clutter\STATUS.txt（每 15 秒刷新）
中断后重新执行上面的 nohup 命令即可续跑（已完成的步骤/模型自动跳过）。

流程：1 下载 Places365 18 类场景背景 → 2 DINO+SAM 生成全部 TrashNet 掩膜（双卡）→ 3 合成 4 个版本
(plain / rand / corr / conf) → 4 冒烟测试 → 5 训练 45 个模型（plain/rand/corr × D4,R18,C8 × 5 种子）
结果：E:\paper chat\clutter\results\（每个模型完成后自动复制）；QC 拼图：E:\paper chat\clutter\qc\
