"""clutter/common.py — shared constants for the synthetic-clutter (causal) experiment."""
import os

WORK = os.environ.get("CLUTTER_WORK", os.path.expanduser("~/projects/r1_revision/clutter_work"))
SYNC = os.environ.get("CLUTTER_SYNC", "/mnt/e/paper chat/clutter")
TN_ROOT = os.environ.get("R1_TRASHNET_ROOT", os.path.expanduser("~/projects/escnn_resnet_wasteclass/trashnet"))

# 6 background groups x 3 Places365 scene categories.  TrashNet class i (sorted order) <-> group i.
# The pairing is arbitrary by design: it only has to create a class-background correlation.
GROUPS = [
    ["kitchen", "pantry", "dining_room"],
    ["street", "alley", "parking_lot"],
    ["office", "conference_room", "classroom"],
    ["garage-indoor", "storage_room", "basement"],
    ["beach", "park", "lawn"],
    ["living_room", "bedroom", "bathroom"],
]
ARMS = ["plain", "rand", "corr", "conf"]   # conf = test-only (background from a WRONG class group)
TRAIN_ARMS = ["plain", "rand", "corr"]
RHO = 0.8            # P(background group == class group) in the 'corr' arm
CANVAS = (512, 384)  # TrashNet native size (W, H)
COMP_SEED = 2026


def list_tn():
    """[(class_dir, file)] of TrashNet, sorted like torchvision ImageFolder."""
    out = []
    for c in sorted(os.listdir(TN_ROOT)):
        d = os.path.join(TN_ROOT, c)
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.lower().endswith((".jpg", ".jpeg", ".png")):
                    out.append((c, f))
    return out
