"""clutter/run_clutter.py — train ONE probe on ONE synthetic-clutter version of TrashNet (native 6 classes,
identical seed split / hyper-parameters / checkpoint rule as r1exp.run_one cond=full), then evaluate:
  * TrashNet test split rendered in every arm (plain / rand / corr / conf) and the ORIGINAL photos
  * zero-shot RealWaste (x_all / x_test / x_bal, logits restricted to the 5 shared classes) — as Tables 2/3
  * Grad-CAM attention concentration (AC, AC_random, hit) on
      - TrashNet test composites (exact paste masks) in arms plain / rand / conf
      - the QC'd random RealWaste sample (auto masks, same images as Table 14)
      - the QC'd random TrashNet sample, original photos (auto masks; in_train flag per seed)
python -m clutter.run_clutter --arm corr --probe D4 --seed 42
"""
import argparse
import csv
import json
import os
import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from PIL import Image
from torch.utils.data import DataLoader

from cam.gradcam import find_pool, mask_tensor
from clutter.common import ARMS, TRAIN_ARMS, WORK
from r1exp.data import SHARED, Domain, ListDataset, balanced_subset, build_transforms
from r1exp.probes import PROBE_CFG, build_probe
from r1exp.run_one import metrics, predict, set_seed

CAM_WORK = os.environ.get("CAM_WORK", os.path.expanduser("~/projects/r1_revision/cam_work"))


def tag_of(a):
    return f"clutter_{a.arm}_{a.probe}_trashnet_s{a.seed}"


def cam_rows(model, items, tf, classes, device, bs=25):
    """items: dicts with path, mask (path), cls (native lower-case name), id, + passthrough keys."""
    store = {}
    h = find_pool(model).register_forward_pre_hook(lambda m, inp: store.__setitem__("A", inp[0]))
    out = []
    for b in range(0, len(items), bs):
        batch = items[b:b + bs]
        x = torch.stack([tf(Image.open(it["path"]).convert("RGB")) for it in batch]).to(device)
        tgt = torch.tensor([classes.index(it["cls"]) for it in batch], device=device)
        with torch.enable_grad():
            logits = model(x)
            A = store["A"]
            G = torch.autograd.grad(logits.gather(1, tgt[:, None]).sum(), A)[0]
        cam = F.relu((G.mean(dim=(2, 3), keepdim=True) * A).sum(1, keepdim=True)).detach()
        cam = F.interpolate(cam, size=(224, 224), mode="bilinear", align_corners=False)[:, 0]
        mn = cam.flatten(1).min(1)[0][:, None, None]
        mx = cam.flatten(1).max(1)[0][:, None, None]
        cam = ((cam - mn) / (mx - mn + 1e-8)).cpu()
        pred = logits.detach().argmax(1).cpu()
        for i, it in enumerate(batch):
            m = mask_tensor(it["mask"])
            c = cam[i]
            r = {k: v for k, v in it.items() if k not in ("path", "mask")}
            r.update(pred=classes[int(pred[i])], correct=int(int(pred[i]) == int(tgt[i])),
                     AC=float((c * m).sum() / (c.sum() + 1e-8)), ACrand=float(m.mean()),
                     hit=int(m.flatten()[int(c.flatten().argmax())] > 0))
            out.append(r)
    h.remove()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", required=True, choices=TRAIN_ARMS)
    ap.add_argument("--probe", required=True, choices=list(PROBE_CFG))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(WORK, "results"))
    ap.add_argument("--limit-batches", type=int, default=0)
    ap.add_argument("--no-ckpt", action="store_true")
    a = ap.parse_args()
    tag = tag_of(a)
    for d in ("", "epochs", "ckpt", "cam"):
        os.makedirs(os.path.join(a.out, d), exist_ok=True)
    set_seed(a.seed)
    torch.backends.cudnn.benchmark = True
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cfg = PROBE_CFG[a.probe]

    comp = {arm: Domain("trashnet", a.seed, root=os.path.join(WORK, "comp", arm)) for arm in ARMS}
    orig = Domain("trashnet", a.seed)
    rel = lambda d: [os.path.relpath(p, d.root) for p, _ in d.samples]  # noqa
    for arm in ARMS:  # identical file lists -> identical splits
        assert rel(comp[arm]) == rel(orig) and comp[arm].split == orig.split, arm
    src, tgt = comp[a.arm], Domain("realwaste", a.seed)
    names = src.lower
    tr_items = src.items(src.split["train"], "native")
    va_items = src.items(src.split["val"], "native")
    tf_tr, tf_ev = build_transforms(224, "none")
    g = torch.Generator()
    g.manual_seed(a.seed)
    tr_dl = DataLoader(ListDataset(tr_items, tf_tr), batch_size=cfg["bs"], shuffle=True, num_workers=a.workers,
                       pin_memory=True, persistent_workers=a.workers > 0, generator=g,
                       worker_init_fn=lambda w: (np.random.seed(a.seed * 100 + w), random.seed(a.seed * 100 + w)))
    model = build_probe(a.probe, len(names)).to(device)
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    opt = optim.SGD(model.parameters(), lr=cfg["lr"], momentum=0.9, weight_decay=1e-4)
    sch = (optim.lr_scheduler.StepLR(opt, step_size=max(1, a.epochs // 3), gamma=0.1) if cfg["sched"] == "step"
           else optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs, eta_min=1e-6))
    crit = nn.CrossEntropyLoss()
    print(f"[{tag}] params={n_params/1e6:.2f}M train/val={len(tr_items)}/{len(va_items)} classes={names}", flush=True)
    ep_csv = os.path.join(a.out, "epochs", f"{tag}.csv")
    with open(ep_csv, "w", newline="") as f:
        csv.writer(f).writerow(["epoch", "train_loss", "train_acc", "val_acc", "val_mAP", "lr", "sec"])
    best_acc, best_ep, best_state, t0 = -1.0, 0, None, time.time()
    for ep in range(1, a.epochs + 1):
        te = time.time()
        model.train()
        tl, tc, tn = 0.0, 0, 0
        for bi, (x, y) in enumerate(tr_dl):
            if a.limit_batches and bi >= a.limit_batches:
                break
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            out = model(x)
            loss = crit(out, y)
            loss.backward()
            if cfg["clip"]:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["clip"])
            opt.step()
            tl += loss.item() * y.size(0)
            tc += (out.argmax(1) == y).sum().item()
            tn += y.size(0)
        lr_now = opt.param_groups[0]["lr"]
        sch.step()
        lv, yv = predict(model, va_items, tf_ev, device, 64, a.workers)
        mv = metrics(lv, yv, names)
        if mv["acc"] > best_acc:
            best_acc, best_ep = mv["acc"], ep
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        with open(ep_csv, "a", newline="") as f:
            csv.writer(f).writerow([ep, f"{tl/max(tn,1):.5f}", f"{tc/max(tn,1):.4f}", f"{mv['acc']:.4f}",
                                    f"{mv['mAP']:.4f}", f"{lr_now:.6f}", f"{time.time()-te:.1f}"])
        print(f"[{tag}] ep {ep:03d} loss={tl/max(tn,1):.4f} tr_acc={tc/max(tn,1):.4f} val_acc={mv['acc']:.4f}", flush=True)
        if not np.isfinite(tl):
            break
    train_min = (time.time() - t0) / 60
    model.load_state_dict(best_state)
    model.eval()
    if not a.no_ckpt:
        torch.save({"state_dict": best_state, "classes": names, "args": vars(a), "best_epoch": best_ep},
                   os.path.join(a.out, "ckpt", f"{tag}.pth"))

    res = {"tag": tag, "args": vars(a), "cfg": cfg, "params": n_params, "best_epoch": best_ep,
           "best_val_acc": best_acc, "train_minutes": train_min, "n_train": len(tr_items), "classes": names}
    cols = [names.index(c) for c in SHARED]
    # ---- TrashNet test split in every rendering ----
    for ev_name, dom in list(comp.items()) + [("orig", orig)]:
        items = dom.items(dom.split["test"], "native")
        lt, yt = predict(model, items, tf_ev, device, 64, a.workers)
        res[f"tn_{ev_name}"] = metrics(lt, yt, names)
        keep = [i for i, t in enumerate(yt.tolist()) if dom.to_shared[t] is not None]
        ys = torch.tensor([dom.to_shared[yt[i].item()] for i in keep])
        res[f"tn_{ev_name}_shared"] = metrics(lt[keep][:, cols], ys, SHARED)
    # ---- zero-shot RealWaste ----
    t_all = tgt.shared_all()
    lx, yx = predict(model, t_all, tf_ev, device, 64, a.workers)
    lx = lx[:, cols]
    res["x_all"] = metrics(lx, yx, SHARED)
    test_set = set(p for p, _ in tgt.items(tgt.split["test"], "shared"))
    it = [i for i, (p, _) in enumerate(t_all) if p in test_set]
    res["x_test"] = metrics(lx[it], yx[it], SHARED)
    ib = balanced_subset(t_all)
    res["x_bal"] = metrics(lx[ib], yx[ib], SHARED)

    # ---- Grad-CAM attention concentration ----
    for mod in model.modules():
        if hasattr(mod, "inplace"):
            mod.inplace = False
    cam_items = []
    for arm in ("plain", "rand", "conf"):
        dom = comp[arm]
        for i in dom.split["test"]:
            p, t = dom.samples[i]
            r = os.path.relpath(p, dom.root)
            cam_items.append(dict(set=f"tn_comp_{arm}", id=r, cls=names[t], in_train=0, path=p,
                                  mask=os.path.join(WORK, "comp", "_mask", os.path.splitext(r)[0] + ".png")))
    excl_f = os.path.join(WORK, "qc_exclude.txt")
    excl = {l.strip() for l in open(excl_f, encoding="utf-8") if l.strip()} if os.path.exists(excl_f) else set()
    train_rel = {os.path.relpath(orig.samples[i][0], orig.root) for i in orig.split["train"]}
    for r in csv.DictReader(open(os.path.join(CAM_WORK, "sample_list.csv"), encoding="utf-8")):
        mk = os.path.join(CAM_WORK, "auto_sample", r["id"] + ".png")
        if r["id"] in excl or not os.path.exists(mk):
            continue
        if r["dataset"] == "realwaste":
            cam_items.append(dict(set="rw_sample", id=r["id"], cls=r["cls"], in_train=0, path=r["image"], mask=mk))
        else:
            cam_items.append(dict(set="tn_orig_sample", id=r["id"], cls=r["cls"],
                                  in_train=int(r["source"] in train_rel), path=r["image"], mask=mk))
    # RealWaste images are scored on the 5 shared classes: restrict logits by wrapping the model
    rows = []
    rw = [x for x in cam_items if x["set"] == "rw_sample"]
    other = [x for x in cam_items if x["set"] != "rw_sample"]
    rows += cam_rows(model, other, tf_ev, names, device)

    class Shared(nn.Module):
        def __init__(self, m):
            super().__init__()
            self.m = m
            for n_ in ("avgpool", "global_pool"):
                if hasattr(m, n_):
                    setattr(self, n_, getattr(m, n_))

        def forward(self, x):
            return self.m(x)[:, cols]
    rows += cam_rows(Shared(model), rw, tf_ev, SHARED, device)
    for r in rows:
        r.update(probe=a.probe, arm=a.arm, seed=a.seed)
    with open(os.path.join(a.out, "cam", f"{tag}.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    summ = {}
    for s in sorted({r["set"] for r in rows}):
        x = [r for r in rows if r["set"] == s and not r["in_train"]]
        if not x:
            continue
        summ[s] = {"n": len(x), "AC": float(np.mean([r["AC"] for r in x])),
                   "ACrand": float(np.mean([r["ACrand"] for r in x])),
                   "gain": float(np.mean([r["AC"] - r["ACrand"] for r in x])),
                   "hit": float(np.mean([r["hit"] for r in x])), "acc": float(np.mean([r["correct"] for r in x]))}
    res["cam"] = summ
    res["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
    path = os.path.join(a.out, f"{tag}.json")
    with open(path + ".tmp", "w") as f:
        json.dump(res, f, indent=1)
    os.replace(path + ".tmp", path)
    print(f"[{tag}] DONE tn_{a.arm}={res['tn_' + a.arm]['acc']:.3f} tn_plain={res['tn_plain']['acc']:.3f} "
          f"tn_conf={res['tn_conf']['acc']:.3f} | RW x_all acc={res['x_all']['acc']:.3f} mAP={res['x_all']['mAP']:.3f} "
          f"| AC gain rw={summ.get('rw_sample', {}).get('gain', float('nan')):+.3f} | {train_min:.1f} min", flush=True)


if __name__ == "__main__":
    main()
