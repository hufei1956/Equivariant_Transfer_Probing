"""clutter/qc_sheet.py — contact sheets: for 8 random images per class, the 4 arms side by side."""
import os
import random
import sys

from PIL import Image, ImageDraw

from clutter.common import WORK
from clutter.common import list_tn


def main(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    items = list_tn()
    rng = random.Random(1)
    for c in sorted({c for c, _ in items}):
        pick = rng.sample([x for x in items if x[0] == c], 8)
        tw, th = 192, 144
        sheet = Image.new("RGB", (tw * 5, th * 8), "white")
        for r, (cc, f) in enumerate(pick):
            ims = [Image.open(os.path.join(WORK, "comp", a, cc, f)).convert("RGB") for a in ("plain", "rand", "corr", "conf")]
            ims.append(Image.open(os.path.join(WORK, "comp", "_mask", cc, os.path.splitext(f)[0] + ".png")).convert("RGB"))
            for k, im in enumerate(ims):
                sheet.paste(im.resize((tw, th)), (k * tw, r * th))
        ImageDraw.Draw(sheet).text((4, 2), f"{c}: plain | rand | corr | conf | paste-mask", fill=(255, 0, 0))
        sheet.save(os.path.join(out_dir, f"qc_{c}.jpg"), quality=85)


if __name__ == "__main__":
    main(sys.argv[1])
