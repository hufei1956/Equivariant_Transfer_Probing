"""clutter/aggregate_clutter.py — tables for the synthetic-clutter experiment.
python -m clutter.aggregate_clutter --res <dir with *.json and cam/*.csv> --meta comp_meta.csv --out clutter_tables.xlsx"""
import argparse
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy import stats

ARMS = ["plain", "rand", "corr"]
PROBES = ["R18", "C8", "D4"]


def ci(x):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    n = len(x)
    if n < 2:
        return (x.mean() if n else np.nan), np.nan, np.nan, n
    h = stats.t.ppf(.975, n - 1) * x.std(ddof=1) / np.sqrt(n)
    p = stats.ttest_1samp(x, 0).pvalue if x.std() > 0 else np.nan
    return x.mean(), h, p, n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--res", required=True)
    ap.add_argument("--meta", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    rows = []
    for f in glob.glob(os.path.join(a.res, "clutter_*.json")):
        r = json.load(open(f))
        d = dict(arm=r["args"]["arm"], probe=r["args"]["probe"], seed=r["args"]["seed"], best_epoch=r["best_epoch"])
        for k in ("tn_plain", "tn_rand", "tn_corr", "tn_conf", "tn_orig"):
            d[k + "_acc"] = r[k]["acc"]
            d[k + "_shared_acc"] = r[k + "_shared"]["acc"]
        d["tn_self_acc"] = r["tn_" + d["arm"]]["acc"]
        for k in ("x_all", "x_bal", "x_test"):
            for m in ("acc", "bal_acc", "mAP"):
                d[f"{k}_{m}"] = r[k][m]
        for s, v in r.get("cam", {}).items():
            d[f"gain_{s}"] = v["gain"]
            d[f"AC_{s}"] = v["AC"]
        rows.append(d)
    D = pd.DataFrame(rows).sort_values(["probe", "arm", "seed"])
    sheets = {"runs": D}
    metrics = ["tn_self_acc", "tn_plain_acc", "tn_conf_acc", "tn_orig_acc", "x_all_acc", "x_all_mAP", "x_bal_acc",
               "x_bal_mAP", "gain_tn_comp_rand", "gain_tn_comp_plain", "gain_rw_sample", "gain_tn_orig_sample"]
    metrics = [m for m in metrics if m in D]
    T = []
    for p in [q for q in PROBES if q in set(D.probe)]:
        for arm in ARMS:
            x = D[(D.probe == p) & (D.arm == arm)]
            if x.empty:
                continue
            row = {"probe": p, "arm": arm, "n": len(x)}
            for m in metrics:
                mu, h, _, _ = ci(x[m] * (100 if "acc" in m or "mAP" in m else 1))
                row[m] = f"{mu:.2f} ± {h:.2f}" if "acc" in m or "mAP" in m else f"{mu:+.3f} ± {h:.3f}"
            T.append(row)
    sheets["T1_means"] = pd.DataFrame(T)

    # effects of clutter vs plain, paired by seed; and D4/C8 - R18 difference-in-differences
    E = []
    piv = {m: D.pivot_table(index="seed", columns=["probe", "arm"], values=m) for m in metrics}
    for m in metrics:
        s = 100 if ("acc" in m or "mAP" in m) else 1
        P = piv[m] * s
        for arm in ("rand", "corr"):
            for p in [q for q in PROBES if (q, arm) in P and (q, "plain") in P]:
                mu, h, pv, n = ci(P[(p, arm)] - P[(p, "plain")])
                E.append(dict(metric=m, contrast=f"{p}: {arm} − plain", mean=mu, ci95=h, p=pv, n=n))
            for p in ("D4", "C8"):
                if all(k in P for k in [(p, arm), (p, "plain"), ("R18", arm), ("R18", "plain")]):
                    dd = (P[(p, arm)] - P[("R18", arm)]) - (P[(p, "plain")] - P[("R18", "plain")])
                    mu, h, pv, n = ci(dd)
                    E.append(dict(metric=m, contrast=f"[{p}−R18]_{arm} − [{p}−R18]_plain", mean=mu, ci95=h, p=pv, n=n))
        for arm in ARMS:
            for p in ("D4", "C8"):
                if (p, arm) in P and ("R18", arm) in P:
                    mu, h, pv, n = ci(P[(p, arm)] - P[("R18", arm)])
                    E.append(dict(metric=m, contrast=f"{p} − R18 | {arm}", mean=mu, ci95=h, p=pv, n=n))
    sheets["T2_effects"] = pd.DataFrame(E)

    # shortcut index for corr-trained models: acc on own-group background vs conflicting background
    S = []
    for p in PROBES:
        x = D[(D.probe == p) & (D.arm == "corr")]
        if len(x):
            mu, h, pv, n = ci((x.tn_corr_acc - x.tn_conf_acc) * 100)
            S.append(dict(probe=p, shortcut_index_pp=mu, ci95=h, p=pv, n=n))
    if {"D4", "R18"} <= set(D.probe):
        a_ = D[(D.arm == "corr")].pivot_table(index="seed", columns="probe", values="tn_corr_acc")
        b_ = D[(D.arm == "corr")].pivot_table(index="seed", columns="probe", values="tn_conf_acc")
        si = (a_ - b_) * 100
        mu, h, pv, n = ci(si["D4"] - si["R18"])
        S.append(dict(probe="D4 − R18", shortcut_index_pp=mu, ci95=h, p=pv, n=n))
    sheets["T3_shortcut"] = pd.DataFrame(S)

    # per-image CAM (exclude full-frame fallbacks for composite sets)
    cams = [pd.read_csv(f) for f in glob.glob(os.path.join(a.res, "cam", "clutter_*.csv"))]
    if cams:
        C = pd.concat(cams)
        C = C[C.in_train == 0]
        if a.meta and os.path.exists(a.meta):
            ff = set(pd.read_csv(a.meta).query("fullframe == 1").relpath)
            C = C[~(C.set.str.startswith("tn_comp") & C.id.isin(ff))]
        C["gain"] = C.AC - C.ACrand
        g = C.groupby(["set", "probe", "arm", "seed"]).gain.mean().reset_index()
        sheets["T4_cam_seed"] = g
        R = []
        for (s, p, arm), x in g.groupby(["set", "probe", "arm"]):
            mu, h, pv, n = ci(x.gain)
            R.append(dict(set=s, probe=p, arm=arm, gain=mu, ci95=h, p_vs0=pv, n_seeds=n,
                          n_images=int(C[(C.set == s) & (C.probe == p) & (C.arm == arm)].id.nunique())))
        sheets["T4_cam"] = pd.DataFrame(R)
    with pd.ExcelWriter(a.out) as xw:
        for k, v in sheets.items():
            v.to_excel(xw, sheet_name=k, index=False)
    pd.set_option("display.width", 250)
    for k in ("T1_means", "T3_shortcut"):
        print("\n==", k)
        print(sheets[k].to_string(index=False))
    print("\n== T2 (selected)")
    t2 = sheets["T2_effects"]
    if len(t2):
        print(t2[t2.metric.isin(["x_all_acc", "x_all_mAP", "x_bal_acc", "gain_rw_sample"])].round(3).to_string(index=False))
    if "T4_cam" in sheets:
        print("\n== T4_cam")
        print(sheets["T4_cam"].round(3).to_string(index=False))


if __name__ == "__main__":
    main()
