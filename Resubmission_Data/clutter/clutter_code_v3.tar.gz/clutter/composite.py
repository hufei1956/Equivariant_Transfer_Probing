"""clutter/composite.py — build the synthetic-clutter versions of TrashNet (run once, any env with numpy+PIL).

For every TrashNet image the object (DINO+SAM mask, feathered) is cut out, rescaled and placed at a random
position on a 512x384 canvas.  Geometry (scale, position, flip-free) is IDENTICAL across arms; only the
background differs:
  plain : flat colour = median of the image's own background pixels (TrashNet look)         -> control
  rand  : Places365 scene, group drawn uniformly (class-independent clutter)
  corr  : Places365 scene from the class's own group with p=RHO, otherwise another group   (spurious context)
  conf  : Places365 scene from a group != class group (test-time conflict set)
Each arm is written as a TrashNet-shaped folder WORK/comp/<arm>/<class>/<file> (same file names -> same
seed splits as the original dataset).  The paste mask is WORK/comp/_mask/<class>/<stem>.png.
"""
import csv
import os
import random

import numpy as np
from PIL import Image, ImageFilter

from clutter.common import CANVAS, COMP_SEED, GROUPS, RHO, TN_ROOT, WORK
from clutter.common import list_tn


def load_bgs():
    pools = []
    for g in GROUPS:
        files = []
        for cat in g:
            d = os.path.join(WORK, "bg", cat)
            files += sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith((".jpg", ".jpeg", ".png")))
        pools.append(files)
    return pools


class Cycler:
    """draw backgrounds without replacement (reshuffle when exhausted) -> minimal re-use"""

    def __init__(self, files, rng):
        self.files, self.rng, self.q = list(files), rng, []

    def next(self):
        if not self.q:
            self.q = self.files[:]
            self.rng.shuffle(self.q)
        return self.q.pop()


def cover(bg, W, H, rng):
    bg = bg.convert("RGB")
    s = max(W / bg.width, H / bg.height)
    bg = bg.resize((max(W, round(bg.width * s)), max(H, round(bg.height * s))), Image.BICUBIC)
    x = rng.randint(0, bg.width - W)
    y = rng.randint(0, bg.height - H)
    return bg.crop((x, y, x + W, y + H))


def main():
    W, H = CANVAS
    items = list_tn()
    classes = sorted({c for c, _ in items})
    assert len(classes) == len(GROUPS), (classes, len(GROUPS))
    pools = load_bgs()
    rng_bg = random.Random(COMP_SEED)
    cyc = [Cycler(p, rng_bg) for p in pools]
    rows = []
    for arm in ("plain", "rand", "corr", "conf", "_mask"):
        for c in classes:
            os.makedirs(os.path.join(WORK, "comp", arm, c), exist_ok=True)
    for n, (c, f) in enumerate(items):
        rng = random.Random(f"{COMP_SEED}-{c}/{f}")
        ci = classes.index(c)
        stem = os.path.splitext(f)[0]
        img = Image.open(os.path.join(TN_ROOT, c, f)).convert("RGB")
        m = Image.open(os.path.join(WORK, "masks", c, stem + ".png")).convert("L")
        if m.size != img.size:
            m = m.resize(img.size, Image.NEAREST)
        ma = np.asarray(m) > 127
        fg = float(ma.mean())
        full = fg < 0.02 or fg > 0.90
        if full:  # unusable mask -> paste the whole photo as a rectangle (same for every arm)
            ma = np.ones_like(ma)
        ys, xs = np.nonzero(ma)
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        # plain background colour = median of the photo's own background pixels
        a = np.asarray(img)
        bgpix = a[~ma] if (~ma).sum() > 500 else a[np.r_[0:5, -5:0]].reshape(-1, 3)
        plain_col = tuple(int(v) for v in np.median(bgpix.reshape(-1, 3), 0))
        obj = img.crop((x0, y0, x1, y1))
        alpha = Image.fromarray((ma[y0:y1, x0:x1] * 255).astype(np.uint8))
        # geometry: longest relative side of the object = s * canvas, s ~ U(0.45, 0.8)
        s = rng.uniform(0.45, 0.80)
        k = s * min(W / obj.width, H / obj.height)
        ow, oh = max(8, round(obj.width * k)), max(8, round(obj.height * k))
        obj = obj.resize((ow, oh), Image.BICUBIC)
        alpha = alpha.resize((ow, oh), Image.BILINEAR).filter(ImageFilter.GaussianBlur(1.5))
        px, py = rng.randint(0, W - ow), rng.randint(0, H - oh)
        pm = Image.new("L", (W, H), 0)
        pm.paste(alpha, (px, py))
        pm.point(lambda v: 255 if v >= 128 else 0).save(os.path.join(WORK, "comp", "_mask", c, stem + ".png"))
        # backgrounds
        g_rand = rng.randrange(len(GROUPS))
        g_corr = ci if rng.random() < RHO else rng.choice([g for g in range(len(GROUPS)) if g != ci])
        g_conf = rng.choice([g for g in range(len(GROUPS)) if g != ci])
        bgs = {"plain": (None, Image.new("RGB", (W, H), plain_col)),
               "rand": (g_rand, None), "corr": (g_corr, None), "conf": (g_conf, None)}
        row = dict(relpath=f"{c}/{f}", cls=c, fg=round(fg, 4), fullframe=int(full), scale=round(s, 3),
                   x=px, y=py, w=ow, h=oh, plain_rgb="%d,%d,%d" % plain_col)
        for arm, (g, bg) in bgs.items():
            if bg is None:
                path = cyc[g].next()
                bg = cover(Image.open(path), W, H, rng)
                row[f"{arm}_group"], row[f"{arm}_bg"] = g, os.path.relpath(path, os.path.join(WORK, "bg"))
            canvas = bg.copy()
            canvas.paste(obj, (px, py), alpha)
            canvas.save(os.path.join(WORK, "comp", arm, c, f), quality=92)
        rows.append(row)
        if n % 200 == 0:
            print(f"{n+1}/{len(items)} {c}/{f} fg={fg:.2f} full={full}", flush=True)
    with open(os.path.join(WORK, "comp", "meta.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    nf = sum(r["fullframe"] for r in rows)
    corr_hit = np.mean([r["corr_group"] == classes.index(r["cls"]) for r in rows])
    print(f"done: {len(rows)} images, fullframe fallback {nf} ({nf/len(rows):.1%}), corr agreement {corr_hit:.3f}")


if __name__ == "__main__":
    main()
