"""clutter/mask_tn.py — Grounding DINO + SAM foreground masks for EVERY TrashNet image (same generic rules as
cam/automask.py, validated on the 30 manual masks: IoU 0.95).  Run in `ultralytics_yolo`, one shard per GPU:
  CUDA_VISIBLE_DEVICES=0 HF_ENDPOINT=https://hf-mirror.com python -m clutter.mask_tn --shard 0/2
Output: WORK/masks/<class>/<stem>.png  (255 = object) + WORK/masks/meta_<k>.json"""
import argparse
import json
import os

import torch
from PIL import Image
from transformers import AutoModelForZeroShotObjectDetection, AutoProcessor, SamModel, SamProcessor

from clutter.common import TN_ROOT, WORK, list_tn

PROMPTS = {
    "cardboard": "a piece of cardboard. a cardboard box.",
    "glass": "a glass bottle. a glass jar. a piece of glass.",
    "metal": "a metal can. a tin can. a piece of metal.",
    "paper": "a sheet of paper. a piece of paper. a newspaper.",
    "plastic": "a plastic bottle. a plastic container. a plastic bag. a piece of plastic.",
    "trash": "a piece of trash. a wrapper. a piece of waste.",
}
DINO_ID = "IDEA-Research/grounding-dino-base"
SAM_ID = "facebook/sam-vit-huge"



def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--box-thr", type=float, default=0.15)
    a = ap.parse_args()
    k, n = map(int, a.shard.split("/"))
    items = list_tn()[k::n]
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    dproc = AutoProcessor.from_pretrained(DINO_ID)
    dino = AutoModelForZeroShotObjectDetection.from_pretrained(DINO_ID).to(dev).eval()
    sproc = SamProcessor.from_pretrained(SAM_ID)
    sam = SamModel.from_pretrained(SAM_ID).to(dev).eval()
    meta_path = os.path.join(WORK, "masks", f"meta_{k}.json")
    meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
    for i, (c, f) in enumerate(items):
        stem = os.path.splitext(f)[0]
        od = os.path.join(WORK, "masks", c)
        os.makedirs(od, exist_ok=True)
        out_png = os.path.join(od, stem + ".png")
        if os.path.exists(out_png) and f"{c}/{f}" in meta:
            continue
        img = Image.open(os.path.join(TN_ROOT, c, f)).convert("RGB")
        W, H = img.size
        with torch.no_grad():
            inp = dproc(images=img, text=PROMPTS[c.lower()], return_tensors="pt").to(dev)
            o = dino(**inp)
            det = dproc.post_process_grounded_object_detection(
                o, inp.input_ids, box_threshold=a.box_thr, text_threshold=a.box_thr, target_sizes=[(H, W)])[0]
        if len(det["scores"]) > 0:
            sc, bx = det["scores"], det["boxes"]
            ok = (sc >= 0.75 * sc.max()).nonzero().flatten()
            area = (bx[ok, 2] - bx[ok, 0]) * (bx[ok, 3] - bx[ok, 1])
            keep = area < 0.9 * W * H
            if keep.any():
                ok, area = ok[keep], area[keep]
            j = int(ok[int(area.argmax())])
            box, dscore = [float(v) for v in bx[j].tolist()], float(sc[j])
        else:
            box, dscore = [0.0, 0.0, float(W), float(H)], 0.0
        with torch.no_grad():
            sin = sproc(img, input_boxes=[[box]], return_tensors="pt").to(dev)
            so = sam(**sin, multimask_output=True)
            masks = sproc.image_processor.post_process_masks(
                so.pred_masks.cpu(), sin["original_sizes"].cpu(), sin["reshaped_input_sizes"].cpu())[0][0]
            iou = so.iou_scores.cpu()[0, 0]
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        inbox = torch.zeros(H, W, dtype=torch.bool)
        inbox[max(y0, 0):min(y1, H), max(x0, 0):min(x1, W)] = True
        best, jj = -1.0, int(iou.argmax())
        for cc in range(masks.shape[0]):
            mc = masks[cc].bool()
            a_in = float((mc & inbox).sum())
            a_all = float(mc.sum()) + 1e-6
            fill = a_in / (float(inbox.sum()) + 1e-6)
            if (a_all - a_in) / a_all < 0.15 and fill > best:
                best, jj = fill, cc
        m = masks[jj].to(torch.uint8) * 255
        Image.frombuffer("L", (W, H), bytes(m.contiguous().view(-1).tolist())).save(out_png)
        meta[f"{c}/{f}"] = dict(box=box, det_score=dscore, sam_iou=float(iou[jj]), fg=float(masks[jj].float().mean()))
        if i % 50 == 0:
            json.dump(meta, open(meta_path, "w"))
            print(f"[shard {k}] {i+1}/{len(items)} {c}/{f} det={dscore:.2f} fg={meta[f'{c}/{f}']['fg']:.2f}", flush=True)
    json.dump(meta, open(meta_path, "w"))
    print(f"[shard {k}] finished {len(items)}", flush=True)


if __name__ == "__main__":
    main()
