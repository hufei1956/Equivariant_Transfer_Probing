"""clutter/fetch_bg.py — download the Places365 validation images of the 18 scene categories in common.GROUPS
from the HF mirror (dataset rumenguin/places365-val, one folder per category, ~100 images each).
Output: WORK/bg/<category>/*.jpg"""
import json
import os
import sys
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from clutter.common import GROUPS, WORK

EP = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com")
REPO = "rumenguin/places365-val"


def get(url, tries=4):
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "curl/7.81.0", "Accept": "*/*"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except Exception as e:  # noqa
            err = e
            if k == tries - 1:
                import subprocess  # last resort: curl (follows redirects)
                r = subprocess.run(["curl", "-sfL", "-m", "120", url], capture_output=True)
                if r.returncode == 0 and r.stdout:
                    return r.stdout
    raise err


def main():
    out = os.path.join(WORK, "bg")
    os.makedirs(out, exist_ok=True)
    report = {}
    for cat in [c for g in GROUPS for c in g]:
        d = os.path.join(out, cat)
        os.makedirs(d, exist_ok=True)
        try:
            tree = json.loads(get(f"{EP}/api/datasets/{REPO}/tree/main/images/{urllib.parse.quote(cat)}"))
        except Exception as e:  # noqa
            print(f"{cat}: listing failed ({e})", flush=True)
            tree = []
        files = [e["path"] for e in tree if e["type"] == "file"]
        todo = [f for f in files if not os.path.exists(os.path.join(d, os.path.basename(f)))]

        def dl(f):
            b = get(f"{EP}/datasets/{REPO}/resolve/main/{urllib.parse.quote(f)}")
            with open(os.path.join(d, os.path.basename(f)), "wb") as fh:
                fh.write(b)
        def safe(f):
            try:
                dl(f)
            except Exception as e:  # noqa
                print("  skip", f, e, flush=True)
        with ThreadPoolExecutor(8) as ex:
            list(ex.map(safe, todo))
        n = len([x for x in os.listdir(d) if x.lower().endswith((".jpg", ".jpeg", ".png"))])
        report[cat] = n
        print(f"{cat}: {n} images", flush=True)
    json.dump(report, open(os.path.join(out, "report.json"), "w"), indent=1)
    from clutter.common import GROUPS as G
    bad = [g for g in G if sum(report.get(c, 0) for c in g) < 150]
    if bad:
        print("TOO FEW IMAGES:", bad)
        sys.exit(1)


if __name__ == "__main__":
    main()
