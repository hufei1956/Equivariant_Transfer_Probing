"""clutter/launch_clutter.py — resumable queue for the clutter experiment (skips finished tags).
tier 1: arms plain/rand/corr x probes D4,R18 x 5 seeds (30 runs) ; tier 2: same with C8 (15 runs)
After every finished run its json/cam csv/epoch csv are copied to SYNC/results (Windows side, E:)."""
import argparse
import os
import shutil
import subprocess
import sys
import time

from clutter.common import SYNC, TRAIN_ARMS, WORK

SEEDS = [42, 123, 2024, 7, 3407]
HEAVY = {"D4": 0, "C8": 1, "R18": 2}


def jobs(tiers):
    J = []
    for t, probes in ((1, ["D4", "R18"]), (2, ["C8"])):
        if t in tiers:
            for seed in SEEDS:
                for p in probes:
                    for arm in TRAIN_ARMS:
                        J.append(dict(tier=t, arm=arm, probe=p, seed=seed,
                                      tag=f"clutter_{arm}_{p}_trashnet_s{seed}"))
    J.sort(key=lambda j: (j["tier"], HEAVY[j["probe"]], SEEDS.index(j["seed"])))
    return J


def sync(out, tag):
    try:
        for sub, ext in (("", ".json"), ("cam", ".csv"), ("epochs", ".csv")):
            src = os.path.join(out, sub, tag + ext)
            if os.path.exists(src):
                d = os.path.join(SYNC, "results", sub)
                os.makedirs(d, exist_ok=True)
                shutil.copy(src, d)
    except Exception as e:  # E: may be unavailable; never kill the queue for that
        print("sync failed:", e, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiers", default="1,2")
    ap.add_argument("--gpus", default="0,1")
    ap.add_argument("--per-gpu", type=int, default=4)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(WORK, "results"))
    a = ap.parse_args()
    tiers = {int(x) for x in a.tiers.split(",")}
    todo = [j for j in jobs(tiers) if not os.path.exists(os.path.join(a.out, j["tag"] + ".json"))]
    print(f"{len(todo)} runs to do", flush=True)
    os.makedirs(os.path.join(WORK, "runlogs"), exist_ok=True)
    slots = [(g, k) for g in a.gpus.split(",") for k in range(a.per_gpu)]
    running, done, failed, queue = {}, 0, [], list(todo)
    while queue or running:
        for slot in slots:
            if slot in running or not queue:
                continue
            j = queue.pop(0)
            cmd = [sys.executable, "-u", "-m", "clutter.run_clutter", "--arm", j["arm"], "--probe", j["probe"],
                   "--seed", str(j["seed"]), "--workers", str(a.workers), "--out", a.out]
            log = open(os.path.join(WORK, "runlogs", j["tag"] + ".log"), "w")
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=slot[0])
            running[slot] = (subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env), j, time.time())
            print(f"{time.strftime('%H:%M:%S')} START gpu{slot[0]} {j['tag']}", flush=True)
        time.sleep(15)
        for slot in list(running):
            p, j, t0 = running[slot]
            if p.poll() is not None:
                del running[slot]
                ok = p.returncode == 0 and os.path.exists(os.path.join(a.out, j["tag"] + ".json"))
                done += ok
                if ok:
                    sync(a.out, j["tag"])
                else:
                    failed.append(j["tag"])
                print(f"{time.strftime('%H:%M:%S')} {'DONE' if ok else 'FAIL'} {j['tag']} ({(time.time()-t0)/60:.1f} min) "
                      f"done={done} failed={len(failed)} queued={len(queue)}", flush=True)
        st = (f"{time.strftime('%Y-%m-%d %H:%M:%S')} TRAINING done={done}/{len(todo)} failed={len(failed)} "
              f"queued={len(queue)} running={len(running)}\n"
              + "".join(f"  gpu{s[0]} {j['tag']} {(time.time()-t0)/60:.0f} min\n" for s, (p, j, t0) in running.items())
              + ("FAILED: " + " ".join(failed) + "\n" if failed else ""))
        for d in (WORK, SYNC):
            try:
                open(os.path.join(d, "STATUS.txt"), "w").write(st)
            except Exception:
                pass
    print("ALL FINISHED. failed:", failed, flush=True)


if __name__ == "__main__":
    main()
