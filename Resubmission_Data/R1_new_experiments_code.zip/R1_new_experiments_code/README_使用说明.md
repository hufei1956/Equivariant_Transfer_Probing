# R1-#1 / R1-#8 / R1-#4 新实验代码说明

这 5 个文件请**直接复制到你本地仓库 `Equivariant_Transfer_Probing` 的根目录**
（与 `dataset.py`、`train.py`、`escnn_train_v2.py` 等平级），因为它们内部用
`from dataset import ...` / `from escnn_train_v2 import ...` 这种相对导入复用
你现有的代码，不是独立可运行的脚本。

我这边的沙箱环境没有装 PyTorch/escnn，也没有你的数据集和已训练的
checkpoint，所以**这些代码没有被实际跑过** —— 建议你先在自己的机器上，用一个
很小的 `--epochs 2` 跑一遍，确认没有环境相关的小问题（比如 escnn 版本差异
导致的 API 不一致），再跑正式的 100 epoch。

---

## 文件一览

| 文件 | 对应审稿意见 | 作用 |
|---|---|---|
| `dataset_matched.py` | R1-#1 | 按类别把 TrashNet / RealWaste 的训练集样本数对齐的核心工具 |
| `train_ablation_matched.py` | R1-#1 | 用对齐后的训练集重跑 ResNet-18 消融训练 |
| `ablation_matched_cross_eval.py` | R1-#1 | 一次性算出匹配前/后的 TN→RW、RW→TN 准确率，判断不对称性是否消失 |
| `train_ablation_augmented.py` | R1-#8 | 给 ResNet-18 加旋转(360°)+双向翻转增强后重跑消融训练 |
| `measure_model_capacity.py` | R1-#4 | 测 5 个探针的参数量/FLOPs，并给出容量对齐的 base_channels 建议 |

---

## 运行顺序

### R1-#1（类别数量匹配）

```bash
python train_ablation_matched.py --dataset-name trashnet  --epochs 100 --batch-size 32
python train_ablation_matched.py --dataset-name realwaste --epochs 100 --batch-size 32
python ablation_matched_cross_eval.py
```
最后一步会同时读取匹配后和原始（未匹配）的 checkpoint，打印两组 TN→RW /
RW→TN 的 Acc/mAP，以及"不对称性差值"（Acc(TN→RW) − Acc(RW→TN)），
这个差值在匹配前后的变化幅度就是回应 R1-#1 需要的核心数字。

> 这一版代码只覆盖了 ResNet-18（最快、最直接的证据）。如果你想要全部 5 个
> 架构在类别匹配后的结果，`dataset_matched.py` 文件末尾的注释里给出了"每个
> 现有训练脚本只需改 2 行"的具体改法，可以照着对 `escnn_train_v2.py` /
> `train_d4_resnet18.py` / `escnn_train_v3_so2.py` 依样画葫芦。

### R1-#8（增强版 ResNet-18）

```bash
python train_ablation_augmented.py --dataset-name trashnet  --epochs 100 --batch-size 32 --cross-eval
python train_ablation_augmented.py --dataset-name realwaste --epochs 100 --batch-size 32 --cross-eval
```
`--cross-eval` 会在训练结束后自动测另一个域的跨域准确率，直接对应 Table 6
里"TN→RW / RW→TN"两列，可以和现有的 C4/C8/D4 那几行放在同一张表里比较。

### R1-#4（参数量 / FLOPs）

先不用任何 checkpoint，直接按文档化的默认超参数测一遍：
```bash
python measure_model_capacity.py --grid-search
```
如果你想按实际训练用的超参数（可能和默认值不同）更准确地测，把 checkpoint
路径传进去（脚本会优先读 checkpoint 里存的 group_type/base_channels 等元数据）：
```bash
python measure_model_capacity.py \
    --resnet18-ckpt checkpoints/best_resnet18_ablation_trashnet.pth \
    --c4-ckpt checkpoints/best_escnn_C4_trashnet.pth \
    --c8-ckpt checkpoints/best_escnn_C8_trashnet.pth \
    --d4-ckpt checkpoints/best_d4_D4_trashnet.pth \
    --so2-ckpt checkpoints/best_so2_v3.pth \
    --grid-search
```

**在运行前请你确认一件事**：仓库里 C4/C8 其实有两套独立实现
（`escnn_train_v2.py::build_equivariant_resnet18` 和
`d4_resnet18.py::c4_resnet18/c8_resnet18`），我从文件命名和 checkpoint 元数据
的证据链推断论文 Table 2/3 用的是前者，但没有 100% 交叉验证。请看一眼你
`checkpoints/` 目录里 C4/C8 对应 checkpoint 的文件名：
- 如果是 `best_escnn_C4_trashnet.pth` 这种 → 用默认的 `--c4-source escnn`（不用改）
- 如果是 `best_d4_C4_trashnet.pth` 这种 → 加上 `--c4-source d4resnet`

SO(2) 同理，仓库里有三个候选脚本（`escnn_train_v2.py` 的 group_type=SO2、
`escnn_train_v3_so2.py::SO2ResNet18`、`escnn_v5_so2.py`），默认按
`escnn_train_v3_so2.py`（README 里文档化的命令对应这个脚本）测，如果你确认
论文数字来自 v5，加 `--so2-source v5`。

`--grid-search` 会额外搜索一遍"改小/改大 base_channels 或 base_width 能不能让
C4/C8/D4 的参数量落到和 ResNet-18 接近"，帮你决定容量对齐重跑该用什么配置——
这一步只是实例化模型数参数，几秒钟就能跑完，不需要 GPU。确定配置后，直接用
仓库已有的 `escnn_train_v2.py --base-channels <N>` 或
`train_d4_resnet18.py --base-width <N>` 重新训练即可，不需要额外写脚本。

---

## 顺带发现的两个问题（不是这次任务要求的，但建议你注意）

1. **R1-#2（标签空间歧义）已经可以确认答案**：我读了 `dataset.py` /
   `Trashnetmodel_test_realwaste.py` / `splits/*.json`，确认所有探针都是在
   **完整原始类别空间**上训练（TrashNet 6 类 / RealWaste 9 类），跨域评估时
   才通过 `FilteredDataset` + 输出 logit 列筛选，只取 5 个共享类别的分数算
   准确率——也就是之前在标注版manuscript里给你留的"方案 A / 方案 B"两个选项
   里的**方案 A**。这一点已经在标注版 manuscript 里帮你留好了方案 A 的文字，
   不需要你额外确认了。

2. **论文方法部分和代码实际用的优化器不一致**：manuscript 里写的是"所有实验
   统一用 Adam，lr=1e-4，batch=32"，但实际代码里：`train.py`/`train_ablation.py`
   用 `SGD(lr=0.01, momentum=0.9)`；`escnn_train_v2.py`（C4/C8）和
   `train_d4_resnet18.py`（D4）也是 `SGD`，各自的 lr/batch/epochs 还都不一样；
   只有 `escnn_train_v3_so2.py`（SO2）用的是 `Adam(lr=0.001)`。这是一个**真实
   的、审稿人目前没提但很可能会被要求解释的问题**——如果二审或后续读者去对照
   代码，会发现方法部分描述和实现不符。我建议在这次修回里顺手把 Section IV-C
   的措辞改成如实描述"各探针按各自架构的收敛特性分别调参（SGD momentum=0.9,
   lr 见附录表 X），而非跨探针统一超参数"，并在附录加一张"各探针实际训练
   超参数"表——这比等被审稿人抓到要主动得多。需要的话我可以帮你把这段文字和
   附录表也一起改到标注版 manuscript 里。
