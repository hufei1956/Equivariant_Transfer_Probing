"""
ablation_matched_cross_eval.py
================================

Reviewer 1, Concern #1 ("R1-#1")：类别数量匹配后，一次性算出 TN→RW 与 RW→TN
两个方向的跨域 Acc / mAP，直接对应论文 Table 6 里 ResNet-18 那一行，方便与
未匹配的原始结果并排比较，判断"TN→RW 领先的不对称性"在样本量匹配后是否
消失或减弱。

前置条件：已经用 train_ablation_matched.py 分别训练出
    checkpoints/best_resnet18_ablation_trashnet_matched.pth
    checkpoints/best_resnet18_ablation_realwaste_matched.pth

用法：
    python ablation_matched_cross_eval.py

输出：
    - 终端打印 TN→RW 和 RW→TN 的 Acc/mAP（连同未匹配基线一起打印，如果能找到
      对应的未匹配 checkpoint best_resnet18_ablation_{trashnet|realwaste}.pth）
    - ablation_matched_cross_eval_results.json：结构化结果，可直接喂给
      Response to Reviewers 里 R1-#1 的表格
"""

import os
import json
from typing import Tuple, List, Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms, models

DATA_ROOT_TRASHNET = "ablation_study_data/trashnet_small"
DATA_ROOT_REALWASTE = "ablation_study_data/realwaste_small"
TEST_CLASSES = ["cardboard", "glass", "metal", "paper", "plastic"]
IMG_SIZE = 224
BATCH_SIZE = 32
NUM_WORKERS = 0


def build_resnet18(num_classes: int) -> nn.Module:
    try:
        model = models.resnet18(weights=None)
    except AttributeError:
        model = models.resnet18(pretrained=False)
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model


def get_eval_transform(img_size: int):
    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    return transforms.Compose([
        transforms.Resize(int(img_size * 1.14)),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])


def accuracy_top1(logits: torch.Tensor, targets: torch.Tensor) -> float:
    preds = logits.argmax(dim=1)
    return (preds == targets).sum().item() / max(1, targets.size(0))


def average_precision(scores: torch.Tensor, labels: torch.Tensor) -> float:
    n_pos = labels.sum().item()
    if n_pos == 0:
        return 0.0
    order = torch.argsort(scores, descending=True)
    y = labels[order]
    tp = torch.cumsum(y, dim=0).float()
    fp = torch.cumsum(1 - y, dim=0).float()
    precision = tp / torch.clamp(tp + fp, min=1.0)
    recall = tp / float(n_pos)
    for i in range(precision.numel() - 2, -1, -1):
        if precision[i] < precision[i + 1]:
            precision[i] = precision[i + 1]
    r = torch.cat([torch.zeros(1), recall, torch.ones(1)])
    p = torch.cat([torch.tensor([precision[0].item()]), precision, torch.tensor([0.0])])
    return float(torch.sum((r[1:] - r[:-1]) * p[1:]).item())


def compute_map(logits: torch.Tensor, targets: torch.Tensor) -> Tuple[float, List[float]]:
    c = logits.size(1)
    probs = torch.softmax(logits, dim=1)
    aps = [average_precision(probs[:, i], (targets == i).to(torch.int64)) for i in range(c)]
    mAP = float(sum(aps) / len(aps)) if aps else 0.0
    return mAP, aps


def find_case_insensitive_dir(base_dir: str, name: str) -> str:
    if os.path.exists(os.path.join(base_dir, name)):
        return os.path.join(base_dir, name)
    for entry in os.scandir(base_dir):
        if entry.is_dir() and entry.name.lower() == name.lower():
            return entry.path
    return os.path.join(base_dir, name)


class FilteredDataset(Dataset):
    def __init__(self, base: datasets.ImageFolder, keep_targets: set, remap: dict):
        self.base = base
        self.indices = [i for i, (_, t) in enumerate(base.samples) if t in keep_targets]
        self.remap = remap

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        x, t_base = self.base[self.indices[idx]]
        return x, self.remap[t_base]


def load_checkpoint_model(ckpt_path: str, device) -> Optional[Tuple[nn.Module, List[str]]]:
    if not os.path.exists(ckpt_path):
        print(f"[跳过] 找不到 checkpoint: {ckpt_path}")
        return None
    ckpt = torch.load(ckpt_path, map_location=device)
    state = ckpt["model_state"] if isinstance(ckpt, dict) and "model_state" in ckpt else ckpt
    if isinstance(ckpt, dict) and "classes" in ckpt:
        classes = [str(c).lower() for c in ckpt["classes"]]
    else:
        classes = ["cardboard", "glass", "metal", "paper", "plastic"]
    model = build_resnet18(num_classes=len(classes)).to(device)
    try:
        model.load_state_dict(state)
    except Exception:
        model.load_state_dict(state, strict=False)
    model.eval()
    return model, classes


def cross_eval(model: nn.Module, model_classes: List[str], target_root: str, device) -> Optional[dict]:
    root = target_root if os.path.exists(target_root) else find_case_insensitive_dir(os.getcwd(), target_root)
    if not os.path.exists(root):
        print(f"[跳过] 找不到目标域数据: {target_root}")
        return None
    tf = get_eval_transform(IMG_SIZE)
    base = datasets.ImageFolder(root=root, transform=tf)
    name_lower = {c.lower(): c for c in base.classes}
    test_lower = [c.lower() for c in TEST_CLASSES]
    present = [c for c in test_lower if c in name_lower]
    if len(present) == 0:
        print(f"[跳过] {target_root} 无匹配类别")
        return None

    keep_targets = {base.class_to_idx[name_lower[c]] for c in present}
    remap = {base.class_to_idx[name_lower[c]]: i for i, c in enumerate(present)}
    ds = FilteredDataset(base, keep_targets, remap)
    loader = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)

    order_to_index = {name: i for i, name in enumerate(model_classes)}
    model_cols = [order_to_index[c] for c in present if c in order_to_index]

    all_logits, all_targets = [], []
    with torch.no_grad():
        for images, targets in loader:
            images = images.to(device, non_blocking=True)
            logits = model(images)[:, model_cols].cpu()
            all_logits.append(logits)
            all_targets.append(targets.cpu())
    logits = torch.cat(all_logits, dim=0)
    targets = torch.cat(all_targets, dim=0)
    acc = accuracy_top1(logits, targets)
    mAP, _ = compute_map(logits, targets)
    return {"n_samples": int(logits.size(0)), "acc": acc, "mAP": mAP}


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results = {}

    for tag, ckpt_name, target_root, direction in [
        ("matched", "best_resnet18_ablation_trashnet_matched.pth", DATA_ROOT_REALWASTE, "TN->RW"),
        ("matched", "best_resnet18_ablation_realwaste_matched.pth", DATA_ROOT_TRASHNET, "RW->TN"),
        ("unmatched", "best_resnet18_ablation_trashnet.pth", DATA_ROOT_REALWASTE, "TN->RW"),
        ("unmatched", "best_resnet18_ablation_realwaste.pth", DATA_ROOT_TRASHNET, "RW->TN"),
    ]:
        ckpt_path = os.path.join("checkpoints", ckpt_name)
        loaded = load_checkpoint_model(ckpt_path, device)
        if loaded is None:
            continue
        model, classes = loaded
        res = cross_eval(model, classes, target_root, device)
        if res is None:
            continue
        key = f"{tag}_{direction.replace('->', '_to_')}"
        results[key] = res
        print(f"[{tag}] {direction}: acc={res['acc']:.4f} mAP={res['mAP']:.4f} (n={res['n_samples']})")

    if "matched_TN_to_RW" in results and "matched_RW_to_TN" in results:
        gap_matched = results["matched_TN_to_RW"]["acc"] - results["matched_RW_to_TN"]["acc"]
        print(f"\n[匹配后不对称性] Acc(TN->RW) - Acc(RW->TN) = {gap_matched:+.4f}")
        results["asymmetry_gap_matched_acc"] = gap_matched
    if "unmatched_TN_to_RW" in results and "unmatched_RW_to_TN" in results:
        gap_unmatched = results["unmatched_TN_to_RW"]["acc"] - results["unmatched_RW_to_TN"]["acc"]
        print(f"[原始(未匹配)不对称性] Acc(TN->RW) - Acc(RW->TN) = {gap_unmatched:+.4f}")
        results["asymmetry_gap_unmatched_acc"] = gap_unmatched

    with open("ablation_matched_cross_eval_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n结果已写入 ablation_matched_cross_eval_results.json")


if __name__ == "__main__":
    main()
