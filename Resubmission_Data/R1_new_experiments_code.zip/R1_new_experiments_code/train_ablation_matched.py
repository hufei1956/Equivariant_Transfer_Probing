"""
train_ablation_matched.py
==========================

Reviewer 1, Concern #1 ("R1-#1")：按类别训练样本数量匹配后重跑消融实验（ResNet-18）。

与 train_ablation.py 几乎完全一致（沿用同一套优化器/学习率/调度器/日志格式，
方便与 Table 6 现有的 ResNet-18 行直接对比），唯一区别是训练集来自
`dataset_matched.py::create_matched_datasets`：TrashNet-small 与 RealWaste-small
的训练集会被裁剪到"每个共享类别取两域中样本数较小者"，因此两个域用于训练的
每类样本数完全相等；val/test 仍是原始 70/15/15 划分，不受影响。

用法（分别训练两侧，各自保存一个 checkpoint）：
    python train_ablation_matched.py --dataset-name trashnet  --epochs 100 --batch-size 32
    python train_ablation_matched.py --dataset-name realwaste --epochs 100 --batch-size 32

产出：
    checkpoints/best_resnet18_ablation_{trashnet|realwaste}_matched.pth
    logs/train_ablation_{trashnet|realwaste}_matched_log.csv

训练完成后用 ablation_matched_cross_eval.py 一次性算出 TN→RW 与 RW→TN 的
Acc / mAP，与现有 Table 6（未匹配）的数字并排比较。
"""

import os
import csv
import time
import argparse
from typing import Tuple, List

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import models

from dataset_matched import create_matched_datasets

# 与消融实验保持一致的两个域根目录（5 类共享子集）
DATA_ROOT_TRASHNET = "ablation_study_data/trashnet_small"
DATA_ROOT_REALWASTE = "ablation_study_data/realwaste_small"


def build_resnet18(num_classes: int, pretrained: bool = False) -> nn.Module:
    try:
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
    except AttributeError:
        model = models.resnet18(pretrained=pretrained)
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model


def accuracy_top1(logits: torch.Tensor, targets: torch.Tensor) -> float:
    preds = logits.argmax(dim=1)
    correct = (preds == targets).sum().item()
    return correct / targets.size(0)


def average_precision(scores: torch.Tensor, labels: torch.Tensor) -> float:
    n_pos = labels.sum().item()
    if n_pos == 0:
        return 0.0
    order = torch.argsort(scores, descending=True)
    y = labels[order]
    tp = torch.cumsum(y, dim=0).float()
    fp = torch.cumsum(1 - y, dim=0).float()
    precision = tp / torch.clamp(tp + fp, min=1.0)
    recall = tp / float(n_pos)
    for i in range(precision.numel() - 2, -1, -1):
        if precision[i] < precision[i + 1]:
            precision[i] = precision[i + 1]
    r = torch.cat([torch.zeros(1), recall, torch.ones(1)])
    p = torch.cat([torch.tensor([precision[0].item()]), precision, torch.tensor([0.0])])
    return float(torch.sum((r[1:] - r[:-1]) * p[1:]).item())


def compute_map(logits: torch.Tensor, targets: torch.Tensor) -> Tuple[float, List[float]]:
    num_classes = logits.size(1)
    probs = torch.softmax(logits, dim=1)
    aps = [average_precision(probs[:, c], (targets == c).to(torch.int64)) for c in range(num_classes)]
    mAP = float(sum(aps) / len(aps)) if aps else 0.0
    return mAP, aps


def train_one_epoch(model, loader, criterion, optimizer, device) -> Tuple[float, float]:
    model.train()
    running_loss, running_correct, total = 0.0, 0, 0
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, targets)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * targets.size(0)
        running_correct += (logits.argmax(dim=1) == targets).sum().item()
        total += targets.size(0)
    return running_loss / max(1, total), running_correct / max(1, total)


@torch.no_grad()
def evaluate(model, loader, device) -> Tuple[float, float]:
    model.eval()
    all_logits, all_targets = [], []
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        logits = model(images)
        all_logits.append(logits.cpu())
        all_targets.append(targets.cpu())
    logits = torch.cat(all_logits, dim=0)
    targets = torch.cat(all_targets, dim=0)
    acc = accuracy_top1(logits, targets)
    mAP, _ = compute_map(logits, targets)
    return acc, mAP


def main():
    parser = argparse.ArgumentParser(description="类别数量匹配后的 ResNet18 消融训练 (R1-#1)")
    parser.add_argument("--dataset-name", type=str, required=True, choices=["trashnet", "realwaste"],
                         help="本次训练用哪个域的匹配后训练集")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--momentum", type=float, default=0.9)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--img-size", type=int, default=224)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--pretrained", action="store_true")
    args = parser.parse_args()

    os.makedirs("checkpoints", exist_ok=True)
    os.makedirs("logs", exist_ok=True)

    (side_a, side_b) = create_matched_datasets(
        data_root_a=DATA_ROOT_TRASHNET,
        data_root_b=DATA_ROOT_REALWASTE,
        split_ratio=(0.7, 0.15, 0.15),
        img_size=args.img_size,
        seed=args.seed,
    )
    train_set, val_set, test_set, classes, split_path = side_a if args.dataset_name == "trashnet" else side_b
    print(f"[匹配后数据集] {args.dataset_name} -> classes={classes}, "
          f"train/val/test={len(train_set)}/{len(val_set)}/{len(test_set)}, split={split_path}")

    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True,
                               num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False,
                             num_workers=args.num_workers, pin_memory=True)
    test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False,
                              num_workers=args.num_workers, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_resnet18(num_classes=len(classes), pretrained=args.pretrained).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=max(1, args.epochs // 3), gamma=0.1)

    log_file = os.path.join("logs", f"train_ablation_{args.dataset_name}_matched_log.csv")
    with open(log_file, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(["epoch", "train_loss", "train_acc", "val_acc", "val_mAP", "lr"])

    best_val_acc = 0.0
    start_time = time.time()
    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_acc, val_map = evaluate(model, val_loader, device)
        scheduler.step()
        with open(log_file, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([epoch, f"{train_loss:.6f}", f"{train_acc:.4f}", f"{val_acc:.4f}",
                                     f"{val_map:.4f}", f"{scheduler.get_last_lr()[0]:.6f}"])
        print(f"Epoch {epoch:02d} | train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
              f"val_acc={val_acc:.4f} val_mAP={val_map:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            ckpt_path = os.path.join("checkpoints", f"best_resnet18_ablation_{args.dataset_name}_matched.pth")
            torch.save({
                "epoch": epoch,
                "model_state": model.state_dict(),
                "optimizer_state": optimizer.state_dict(),
                "val_acc": val_acc,
                "val_mAP": val_map,
                "classes": classes,
                "pretrained": args.pretrained,
                "matched": True,
            }, ckpt_path)
            print(f"已保存最佳模型到: {ckpt_path}")

    print(f"训练完成，总耗时 {(time.time() - start_time)/60:.1f} 分钟")
    test_acc, test_map = evaluate(model, test_loader, device)
    print(f"[Test] top1_acc={test_acc:.4f} mAP={test_map:.4f}")
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(["test", "", "", f"{test_acc:.4f}", f"{test_map:.4f}", ""])


if __name__ == "__main__":
    main()
