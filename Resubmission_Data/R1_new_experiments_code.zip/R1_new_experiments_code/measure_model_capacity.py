"""
measure_model_capacity.py
===========================

Reviewer 1, Concern #4 ("R1-#4")：报告 5 个探针（ResNet-18 baseline / C4 / C8 /
D4 / SO(2)）的参数量与 FLOPs，并给出"按参数量做容量对齐"的建议配置，供讨论
"C4/D4 的优势是否只是因为参数更多"。

已知的实现细节 / 需要你确认的地方
----------------------------------
仓库里 C4/C8 实际上存在**两套互相独立的实现**：
  (a) escnn_train_v2.py :: build_equivariant_resnet18(group_type, maximum_frequency, base_channels)
      —— 通用 ESCNN 构建器，命名产物如 best_escnn_C8_trashnet.pth
  (b) d4_resnet18.py :: c4_resnet18(num_classes) / c8_resnet18(num_classes)
      —— 与 D4 共用同一个 D4ResNet 骨架 (N=4/8, f=False)，命名产物如 best_d4_D4_trashnet.pth

从 README 的命名规范 (`best_{架构/群}_{数据集}.pth`)、`Trashnetmodel_test_realwaste.py`
里的 `MODEL_FILES` 字典 (`best_escnn_C4_trashnet.pth` / `best_escnn_C8_trashnet.pth`)
以及 `logs/escnn_C4_trashnet_log.csv` 这样的日志文件名来看，论文 Table 2/3 里的
C4/C8 数字大概率来自 (a)。但这一点本脚本无法仅从代码静态确认 —— 请在你本地
`checkpoints/` 目录里确认实际使用的 checkpoint 文件名前缀（`best_escnn_C*` 还是
`best_d4_C*`），并通过 `--c4-source {escnn,d4resnet}` / `--c8-source {escnn,d4resnet}`
显式指定，避免报告了错误实现的参数量/FLOPs。

同样，SO(2) 在仓库里也有三个脚本 (`escnn_train_v2.py` 的 group_type="SO2"、
`escnn_train_v3_so2.py::SO2ResNet18`、`escnn_v5_so2.py`)。本脚本默认按
`escnn_train_v3_so2.py::SO2ResNet18` 重建（这是 README 文档化的命令
`python escnn_train_v3_so2.py --group SO2 --max-frequency 4` 所对应的脚本），
如果你论文里报告的 SO(2) 数字来自 v5，请用 `--so2-source v5` 切换。

用法
----
最简单：不传任何 checkpoint，只按文档化的默认超参数实例化每个架构，测参数量/FLOPs
（不需要 GPU、不需要数据集，只需要 torch + escnn 环境）：

    python measure_model_capacity.py

如果想按实际训练时用的超参数重建（更准确，因为 base_channels/max_frequency
等可能被命令行参数覆盖过默认值），把已有 checkpoint 传进来，脚本会优先读取
checkpoint 里存的 group_type/base_channels/max_frequency 等元数据：

    python measure_model_capacity.py \\
        --resnet18-ckpt checkpoints/best_resnet18_ablation_trashnet.pth \\
        --c4-ckpt checkpoints/best_escnn_C4_trashnet.pth --c4-source escnn \\
        --c8-ckpt checkpoints/best_escnn_C8_trashnet.pth --c8-source escnn \\
        --d4-ckpt checkpoints/best_d4_D4_trashnet.pth \\
        --so2-ckpt checkpoints/best_so2_v3.pth --so2-source v3

输出：
    - 终端打印每个探针的参数量 (Params) 与 FLOPs（若 FLOPs 统计失败，会打印
      清楚的原因，不会静默给出错误数字）
    - model_capacity_report.json：结构化结果，可直接用于 R1-#4 表格
    - 额外打印"参数量最接近 ResNet-18 baseline 的 base_channels/base_width 建议值"，
      用于做容量对齐重跑（见下方"容量对齐重跑"一节）

FLOPs 统计方法
--------------
优先用 PyTorch 内置的 `torch.utils.flop_counter.FlopCounterMode`（torch>=2.1，
基于 __torch_dispatch__ 拦截真实执行的 ATen 算子，不依赖对模块类型的静态识别，
因此对 escnn 的 R2Conv 这种"内部用基展开生成卷积核、再调用 F.conv2d"的自定义
模块也能正确统计，比按 nn.Module 类型匹配的传统 profiler 更稳健）。如果 torch
版本过低或统计失败，回退到 `fvcore.nn.FlopCountAnalysis`（同样是 ATen 级别
trace，但依赖静态 jit trace，对某些动态控制流可能失败）。两者都失败时，脚本
只报告参数量，并在输出里明确说明"FLOPs 未能统计"，不会编造数字。

容量对齐重跑（用于回应"C4/D4 的优势是否只是因为参数更多"）
--------------------------------------------------------------
本脚本本身只做测量，不做自动的容量对齐重训练——因为容量对齐涉及在
"改变 base_channels/base_width 到底改到多少"这个问题上做取舍判断，而这属于
需要人工确认的实验设计决策，不适合自动化。脚本会打印一个"候选 base_channels/
base_width 网格搜索"结果（只实例化模型数参数、不训练），帮你直接读出"哪个
base_channels 能让 C4/C8/D4 的参数量落在 ResNet-18 baseline 的 ±10% 以内"，
你确认后，用仓库已有的训练脚本 + 对应的 `--base-channels` / `--base-width`
参数重跑一遍即可（不需要新脚本，这两个参数本来就是 escnn_train_v2.py /
train_d4_resnet18.py 的现成 CLI 选项）。
"""

import os
import sys
import json
import argparse
from typing import Optional, Dict, Any, Tuple

import torch
import torch.nn as nn


def count_params(model: nn.Module) -> Dict[str, int]:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total_params": int(total), "trainable_params": int(trainable)}


def measure_flops(model: nn.Module, dummy_input: torch.Tensor) -> Tuple[Optional[float], str]:
    """
    返回 (GFLOPs 或 None, 使用的方法说明字符串)。
    统计的是一次前向传播 (batch=1) 的乘加次数，按惯例乘以 2 计为 FLOPs
    （1 次乘加 = 2 FLOPs），并换算成 GFLOPs。
    """
    model.eval()
    # 方法 1: torch 内置 FlopCounterMode（推荐，见模块 docstring）
    try:
        from torch.utils.flop_counter import FlopCounterMode
        with torch.no_grad():
            with FlopCounterMode(model, display=False) as fcm:
                model(dummy_input)
            total_flops = fcm.get_total_flops()
        return total_flops / 1e9, "torch.utils.flop_counter.FlopCounterMode"
    except Exception as e1:
        print(f"  [FlopCounterMode 失败] {e1}")

    # 方法 2: fvcore（回退）
    try:
        from fvcore.nn import FlopCountAnalysis
        with torch.no_grad():
            fca = FlopCountAnalysis(model, dummy_input)
            fca.unsupported_ops_warnings(False)
            total_flops = fca.total()
        # fvcore 的 total() 统计的是乘加次数 (MACs)，按惯例 *2 换算为 FLOPs
        return (total_flops * 2) / 1e9, "fvcore.nn.FlopCountAnalysis (MACs*2)"
    except Exception as e2:
        print(f"  [fvcore 失败] {e2}")

    return None, "均未成功（torch 版本过低 / escnn 前向不可 trace），仅报告参数量"


def load_ckpt_meta(ckpt_path: Optional[str], device) -> Dict[str, Any]:
    if not ckpt_path or not os.path.exists(ckpt_path):
        return {}
    ckpt = torch.load(ckpt_path, map_location=device)
    if not isinstance(ckpt, dict):
        return {}
    meta = {k: v for k, v in ckpt.items() if k != "model_state" and k != "optimizer_state"}
    return meta


# ---------------------------------------------------------------------------
# 5 个探针的构建函数（直接复用/镜像各训练脚本里的 builder，保证架构定义一致）
# ---------------------------------------------------------------------------

def build_probe_resnet18(num_classes: int) -> nn.Module:
    from torchvision import models
    try:
        model = models.resnet18(weights=None)
    except AttributeError:
        model = models.resnet18(pretrained=False)
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model


def build_probe_escnn(num_classes: int, group_type: str, max_frequency: int, base_channels: int) -> nn.Module:
    from escnn_train_v2 import build_equivariant_resnet18
    return build_equivariant_resnet18(
        num_classes=num_classes, group_type=group_type,
        maximum_frequency=max_frequency, base_channels=base_channels,
    )


def build_probe_d4resnet(num_classes: int, group: str, base_width: int) -> nn.Module:
    from d4_resnet18 import d4_resnet18, c4_resnet18, c8_resnet18, d8_resnet18
    builders = {"D4": d4_resnet18, "C4": c4_resnet18, "C8": c8_resnet18, "D8": d8_resnet18}
    if group not in builders:
        raise ValueError(f"未知 group={group}，可选 {list(builders)}")
    return builders[group](num_classes=num_classes, base_width=base_width)


def build_probe_so2(num_classes: int, source: str, base_channels: int, max_freq: int) -> nn.Module:
    if source == "v3":
        from escnn_train_v3_so2 import SO2ResNet18
        return SO2ResNet18(num_classes, base_channels=base_channels, max_freq=max_freq)
    elif source == "v5":
        from escnn_v5_so2 import SO2ResNet18  # 若 v5 中类名不同，请按报错信息调整
        return SO2ResNet18(num_classes=num_classes, base_channels=base_channels, max_frequency=max_freq)
    elif source == "escnn_v2":
        from escnn_train_v2 import build_equivariant_resnet18
        return build_equivariant_resnet18(
            num_classes=num_classes, group_type="SO2",
            maximum_frequency=max_freq, base_channels=base_channels,
        )
    else:
        raise ValueError(f"未知 so2 source={source}")


def try_build_and_measure(name: str, builder, num_classes: int, img_size: int, device) -> Dict[str, Any]:
    print(f"\n=== {name} ===")
    try:
        model = builder().to(device)
    except Exception as e:
        print(f"  [构建失败] {e}")
        return {"name": name, "error": str(e)}
    model.eval()
    params = count_params(model)
    dummy = torch.randn(1, 3, img_size, img_size, device=device)
    gflops, method = measure_flops(model, dummy)
    result = {
        "name": name,
        "total_params": params["total_params"],
        "total_params_M": round(params["total_params"] / 1e6, 4),
        "trainable_params": params["trainable_params"],
        "gflops": None if gflops is None else round(gflops, 4),
        "flops_method": method,
    }
    print(f"  Params: {result['total_params']:,} ({result['total_params_M']} M)")
    if gflops is not None:
        print(f"  FLOPs : {result['gflops']} GFLOPs  (method: {method})")
    else:
        print(f"  FLOPs : 未能统计 ({method})")
    del model
    return result


def capacity_matched_grid_search(target_params: int, group: str, base_values, num_classes: int,
                                  builder_fn) -> Dict[str, Any]:
    """在给定的 base_channels/base_width 候选值里，找出参数量最接近 target_params 的一个。"""
    rows = []
    best = None
    for bc in base_values:
        try:
            m = builder_fn(bc)
            n = sum(p.numel() for p in m.parameters())
            del m
        except Exception as e:
            rows.append({"base": bc, "error": str(e)})
            continue
        diff = abs(n - target_params)
        rows.append({"base": bc, "params": int(n), "params_M": round(n / 1e6, 4),
                      "diff_vs_target": int(n - target_params)})
        if best is None or diff < best["_diff"]:
            best = {"base": bc, "params": int(n), "_diff": diff}
    return {"group": group, "grid": rows, "closest_to_target": best}


def main():
    parser = argparse.ArgumentParser(description="5 个探针的参数量 / FLOPs 测量 + 容量对齐建议 (R1-#4)")
    parser.add_argument("--num-classes", type=int, default=5, help="分类头类别数（消融/跨域实验用 5）")
    parser.add_argument("--img-size", type=int, default=224)

    parser.add_argument("--resnet18-ckpt", type=str, default=None)

    parser.add_argument("--c4-source", type=str, default="escnn", choices=["escnn", "d4resnet"])
    parser.add_argument("--c4-ckpt", type=str, default=None)
    parser.add_argument("--c8-source", type=str, default="escnn", choices=["escnn", "d4resnet"])
    parser.add_argument("--c8-ckpt", type=str, default=None)

    parser.add_argument("--d4-ckpt", type=str, default=None)
    parser.add_argument("--d4-base-width", type=int, default=64)

    parser.add_argument("--so2-source", type=str, default="v3", choices=["v3", "v5", "escnn_v2"])
    parser.add_argument("--so2-ckpt", type=str, default=None)
    parser.add_argument("--so2-base-channels", type=int, default=16)
    parser.add_argument("--so2-max-freq", type=int, default=4)

    parser.add_argument("--escnn-base-channels", type=int, default=16,
                         help="C4/C8 (escnn_train_v2 实现) 的默认 base_channels，会被 checkpoint 元数据覆盖")
    parser.add_argument("--escnn-max-frequency", type=int, default=8,
                         help="C4/C8 (escnn_train_v2 实现) 的默认 max_frequency，会被 checkpoint 元数据覆盖")

    parser.add_argument("--grid-search", action="store_true",
                         help="额外做一次 base_channels/base_width 网格搜索，输出与 ResNet-18 参数量最接近的配置")
    parser.add_argument("--output", type=str, default="model_capacity_report.json")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    results = []

    # --- ResNet-18 baseline ---
    results.append(try_build_and_measure(
        "ResNet18_baseline",
        lambda: build_probe_resnet18(args.num_classes),
        args.num_classes, args.img_size, device,
    ))
    resnet18_params = results[-1].get("total_params")

    # --- C4 ---
    c4_meta = load_ckpt_meta(args.c4_ckpt, device)
    if args.c4_source == "escnn":
        bc = int(c4_meta.get("base_channels", args.escnn_base_channels))
        mf = int(c4_meta.get("max_frequency", args.escnn_max_frequency))
        results.append(try_build_and_measure(
            f"C4_escnn(base_channels={bc},max_freq={mf})",
            lambda: build_probe_escnn(args.num_classes, "C4", mf, bc),
            args.num_classes, args.img_size, device,
        ))
    else:
        results.append(try_build_and_measure(
            f"C4_d4resnet(base_width={args.d4_base_width})",
            lambda: build_probe_d4resnet(args.num_classes, "C4", args.d4_base_width),
            args.num_classes, args.img_size, device,
        ))

    # --- C8 ---
    c8_meta = load_ckpt_meta(args.c8_ckpt, device)
    if args.c8_source == "escnn":
        bc = int(c8_meta.get("base_channels", args.escnn_base_channels))
        mf = int(c8_meta.get("max_frequency", args.escnn_max_frequency))
        results.append(try_build_and_measure(
            f"C8_escnn(base_channels={bc},max_freq={mf})",
            lambda: build_probe_escnn(args.num_classes, "C8", mf, bc),
            args.num_classes, args.img_size, device,
        ))
    else:
        results.append(try_build_and_measure(
            f"C8_d4resnet(base_width={args.d4_base_width})",
            lambda: build_probe_d4resnet(args.num_classes, "C8", args.d4_base_width),
            args.num_classes, args.img_size, device,
        ))

    # --- D4 ---
    results.append(try_build_and_measure(
        f"D4_d4resnet(base_width={args.d4_base_width})",
        lambda: build_probe_d4resnet(args.num_classes, "D4", args.d4_base_width),
        args.num_classes, args.img_size, device,
    ))

    # --- SO(2) ---
    so2_meta = load_ckpt_meta(args.so2_ckpt, device)
    so2_bc = int(so2_meta.get("base_channels", args.so2_base_channels))
    so2_mf = int(so2_meta.get("max_frequency", so2_meta.get("max_freq", args.so2_max_freq)))
    results.append(try_build_and_measure(
        f"SO2_{args.so2_source}(base_channels={so2_bc},max_freq={so2_mf})",
        lambda: build_probe_so2(args.num_classes, args.so2_source, so2_bc, so2_mf),
        args.num_classes, args.img_size, device,
    ))

    # --- 容量对齐网格搜索（可选） ---
    grid_results = []
    if args.grid_search and resnet18_params:
        print("\n=== 容量对齐网格搜索 (目标: 接近 ResNet-18 baseline 参数量 "
              f"{resnet18_params:,}) ===")
        grid_results.append(capacity_matched_grid_search(
            resnet18_params, "D4 (base_width)", [16, 24, 32, 48, 64],
            args.num_classes, lambda bw: build_probe_d4resnet(args.num_classes, "D4", bw),
        ))
        grid_results.append(capacity_matched_grid_search(
            resnet18_params, "C4/C8 escnn (base_channels)", [8, 16, 24, 32, 48, 64],
            args.num_classes,
            lambda bc: build_probe_escnn(args.num_classes, "C8", args.escnn_max_frequency, bc),
        ))
        for gr in grid_results:
            print(f"\n[{gr['group']}]")
            for row in gr["grid"]:
                if "error" in row:
                    print(f"  base={row['base']}: 构建失败 ({row['error']})")
                else:
                    print(f"  base={row['base']:>3d}: params={row['params']:>10,} "
                          f"({row['params_M']} M)  diff={row['diff_vs_target']:+,}")
            if gr["closest_to_target"]:
                print(f"  -> 最接近的配置: base={gr['closest_to_target']['base']} "
                      f"(params={gr['closest_to_target']['params']:,})")

    report = {"num_classes": args.num_classes, "img_size": args.img_size,
              "probes": results, "capacity_grid_search": grid_results}
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n结果已写入 {args.output}")


if __name__ == "__main__":
    main()
