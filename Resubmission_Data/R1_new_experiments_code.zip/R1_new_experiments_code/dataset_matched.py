"""
dataset_matched.py
===================

Reviewer 1, Concern #1 ("R1-#1")：按类别训练样本数量匹配后重跑跨域实验。

背景
----
现有 `dataset.py::create_trashnet_datasets` 对每个域（TrashNet / RealWaste）
各自独立做 70/15/15 的按类别分层划分。这意味着两个域各自的"每类训练样本数"
是不相等的 —— 例如消融实验用的 5 类子集里：

    trashnet_small (splits/trashnet_small_split.json):  n_train = 1671 (5类, 约334/类)
    realwaste_small(splits/realwaste_small_split.json): n_train = 2163 (5类, 约433/类)

审稿人担心：论文中报告的 "TN→RW 领先的不对称性"（即以 TrashNet 训练的探针
迁移到 RealWaste 的效果，系统性优于反方向）有可能只是训练样本量不对等的
副产品，而不是两个数据集本身几何/纹理质量差异的体现。

本模块做的事
------------
在**不改动**现有 `dataset.py` / 现有 `splits/*.json`（其他所有实验的可复现性
依赖它们）的前提下，新增一套"类别数量匹配"的划分逻辑：

1. 分别对两个域按类别做 70/15/15 划分（与 `dataset.py` 完全相同的算法，
   使用相同的 `_compute_split_indices_by_class`，因此 val/test 不受影响，
   只对齐 **train** 集合的每类样本数）。
2. 对每个类别（要求两个域的类别名在忽略大小写后一一对应，例如
   'plastic' <-> 'Plastic'），取两个域该类别训练样本数的较小值 n_min(c)。
3. 用同一个随机种子分别从两个域的该类别训练样本中不放回抽样 n_min(c) 个，
   得到"类别数量匹配"的训练子集；val/test 集合保持原始划分不变（评估阶段
   的类别不平衡不是本条审稿意见关心的问题）。
4. 划分结果写入新文件 `splits/{basename}_matched_pair_{other_basename}.json`，
   与原始 split 文件相互独立，不会覆盖或干扰任何已有实验。

用法
----
    from dataset_matched import create_matched_datasets

    (tn_train, tn_val, tn_test, tn_classes, tn_split_path), \\
    (rw_train, rw_val, rw_test, rw_classes, rw_split_path) = create_matched_datasets(
        data_root_a="ablation_study_data/trashnet_small",
        data_root_b="ablation_study_data/realwaste_small",
        split_ratio=(0.7, 0.15, 0.15),
        img_size=224,
        seed=42,
    )

返回的每一侧都是与 `dataset.py::create_trashnet_datasets` **完全相同的返回值
形状** (Subset, Subset, Subset, List[str], str)，因此可以直接喂给仓库里任何
现有训练脚本（`train.py` / `train_ablation.py` / `escnn_train_v2.py` /
`train_d4_resnet18.py` / `escnn_train_v3_so2.py` / `escnn_v5_so2.py`）—— 只需
把脚本里 `create_trashnet_datasets(data_root=...)` 的调用换成从这里拿到的
`tn_train`/`rw_train` 等现成对象即可，不需要重写任何训练逻辑。每个脚本需要
改动的地方只有两行，见文末 "如何接入现有 5 个训练脚本" 的说明。
"""

import os
import json
import random
from typing import Tuple, List, Dict

from torch.utils.data import Subset
from torchvision import datasets

from dataset import _list_class_dirs, _build_transforms, _compute_split_indices_by_class


def _class_name_key(name: str) -> str:
    """忽略大小写 / 首尾空格，用于跨域类别名对齐（TrashNet 用小写，RealWaste 首字母大写）。"""
    return name.strip().lower()


def _per_class_train_indices(
    dataset: datasets.ImageFolder, train_idx: List[int]
) -> Dict[int, List[int]]:
    by_class: Dict[int, List[int]] = {}
    for i in train_idx:
        _, target = dataset.samples[i]
        by_class.setdefault(target, []).append(i)
    return by_class


def create_matched_datasets(
    data_root_a: str,
    data_root_b: str,
    split_ratio: Tuple[float, float, float] = (0.7, 0.15, 0.15),
    img_size: int = 224,
    seed: int = 42,
):
    """
    为两个域生成"训练集按类别数量匹配"的 train/val/test 数据集。

    - data_root_a / data_root_b: 两个域的数据根目录，例如
        "ablation_study_data/trashnet_small" 和 "ablation_study_data/realwaste_small"
      （也可以传完整数据集根目录 "dataset-resized" / "RealWaste"，但论文里
      R1-#1 讨论的是消融用的 5 类共享子集，因此推荐用 *_small 目录，保证类别
      与 Table 6 一致）。
    - split_ratio / img_size / seed: 含义与 `dataset.py::create_trashnet_datasets`
      完全一致。

    返回:
        (train_a, val_a, test_a, classes_a, split_path_a),
        (train_b, val_b, test_b, classes_b, split_path_b)
    """
    assert os.path.isdir(data_root_a), f"数据目录不存在: {data_root_a}"
    assert os.path.isdir(data_root_b), f"数据目录不存在: {data_root_b}"

    classes_a = _list_class_dirs(data_root_a)
    classes_b = _list_class_dirs(data_root_b)
    key_to_a = {_class_name_key(c): c for c in classes_a}
    key_to_b = {_class_name_key(c): c for c in classes_b}
    shared_keys = sorted(set(key_to_a) & set(key_to_b))
    assert len(shared_keys) > 0, (
        f"两个域没有可对齐的共享类别名: {classes_a} vs {classes_b}"
    )
    if set(key_to_a) != set(key_to_b):
        only_a = set(key_to_a) - set(key_to_b)
        only_b = set(key_to_b) - set(key_to_a)
        print(f"[警告] 以下类别只出现在其中一个域，将被忽略: A-only={only_a} B-only={only_b}")

    tfs_a = _build_transforms(img_size)
    tfs_b = _build_transforms(img_size)

    base_a = datasets.ImageFolder(root=data_root_a, transform=None)
    base_b = datasets.ImageFolder(root=data_root_b, transform=None)

    splits_a = _compute_split_indices_by_class(base_a, split_ratio, seed)
    splits_b = _compute_split_indices_by_class(base_b, split_ratio, seed)

    train_by_class_a = _per_class_train_indices(base_a, splits_a["train"])
    train_by_class_b = _per_class_train_indices(base_b, splits_b["train"])

    rng = random.Random(seed)
    matched_train_a: List[int] = []
    matched_train_b: List[int] = []
    per_class_report = []

    for key in shared_keys:
        name_a = key_to_a[key]
        name_b = key_to_b[key]
        idx_a_all = train_by_class_a.get(base_a.class_to_idx[name_a], [])
        idx_b_all = train_by_class_b.get(base_b.class_to_idx[name_b], [])
        n_min = min(len(idx_a_all), len(idx_b_all))
        if n_min == 0:
            print(f"[警告] 类别 '{key}' 在某一域训练集中样本数为 0，已跳过该类别")
            continue

        idx_a = idx_a_all[:]
        idx_b = idx_b_all[:]
        rng.shuffle(idx_a)
        rng.shuffle(idx_b)
        matched_train_a.extend(idx_a[:n_min])
        matched_train_b.extend(idx_b[:n_min])
        per_class_report.append(
            {"class": key, "n_a_before": len(idx_a_all), "n_b_before": len(idx_b_all), "n_matched": n_min}
        )

    print("[类别数量匹配报告]")
    for row in per_class_report:
        print(f"  {row['class']:>12s}: A={row['n_a_before']:>4d} -> {row['n_matched']:>4d} | "
              f"B={row['n_b_before']:>4d} -> {row['n_matched']:>4d}")
    print(f"  合计: A {len(matched_train_a)} 张, B {len(matched_train_b)} 张 (原始 A={len(splits_a['train'])}, B={len(splits_b['train'])})")

    # 落盘，便于复现 / 供论文附录引用
    os.makedirs("splits", exist_ok=True)
    basename_a = os.path.basename(os.path.normpath(data_root_a))
    basename_b = os.path.basename(os.path.normpath(data_root_b))
    split_path_a = os.path.join("splits", f"{basename_a}_matched_with_{basename_b}_split.json")
    split_path_b = os.path.join("splits", f"{basename_b}_matched_with_{basename_a}_split.json")

    def _dump(path, base_dataset, data_root, train_idx, val_idx, test_idx):
        def to_rel(indices):
            return [os.path.relpath(base_dataset.samples[i][0], data_root).replace("\\", "/") for i in indices]
        payload = {
            "classes": base_dataset.classes,
            "ratio": split_ratio,
            "seed": seed,
            "note": "train 集合已按共享类别数量匹配（跨域取每类样本数较小者）；val/test 为原始 70/15/15 划分，未做匹配。",
            "per_class_report": per_class_report,
            "train": to_rel(train_idx),
            "val": to_rel(val_idx),
            "test": to_rel(test_idx),
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    _dump(split_path_a, base_a, data_root_a, matched_train_a, splits_a["val"], splits_a["test"])
    _dump(split_path_b, base_b, data_root_b, matched_train_b, splits_b["val"], splits_b["test"])

    train_full_a = datasets.ImageFolder(root=data_root_a, transform=tfs_a["train"])
    eval_full_a = datasets.ImageFolder(root=data_root_a, transform=tfs_a["eval"])
    train_full_b = datasets.ImageFolder(root=data_root_b, transform=tfs_b["train"])
    eval_full_b = datasets.ImageFolder(root=data_root_b, transform=tfs_b["eval"])

    train_a = Subset(train_full_a, matched_train_a)
    val_a = Subset(eval_full_a, splits_a["val"])
    test_a = Subset(eval_full_a, splits_a["test"])

    train_b = Subset(train_full_b, matched_train_b)
    val_b = Subset(eval_full_b, splits_b["val"])
    test_b = Subset(eval_full_b, splits_b["test"])

    return (
        (train_a, val_a, test_a, train_full_a.classes, split_path_a),
        (train_b, val_b, test_b, train_full_b.classes, split_path_b),
    )


if __name__ == "__main__":
    # 自检：与消融实验使用的同一对 5 类子集做类别匹配
    (a, b) = create_matched_datasets(
        data_root_a="ablation_study_data/trashnet_small",
        data_root_b="ablation_study_data/realwaste_small",
        split_ratio=(0.7, 0.15, 0.15),
        img_size=224,
        seed=42,
    )
    (tr_a, va_a, te_a, classes_a, path_a) = a
    (tr_b, va_b, te_b, classes_b, path_b) = b
    print(f"A: classes={classes_a}, train/val/test={len(tr_a)}/{len(va_a)}/{len(te_a)}, split={path_a}")
    print(f"B: classes={classes_b}, train/val/test={len(tr_b)}/{len(va_b)}/{len(te_b)}, split={path_b}")

"""
如何接入现有 5 个训练脚本（每个只需改 2 行）
============================================

以 escnn_train_v2.py（C4/C8）为例，原来是：

    train_set, val_set, test_set, classes, split_path = create_trashnet_datasets(
        data_root=args.data_root, split_ratio=(0.7, 0.15, 0.15),
        img_size=args.img_size, seed=args.seed,
    )

改成（TrashNet 一侧；RealWaste 一侧同理，取 b 分支）：

    from dataset_matched import create_matched_datasets
    (a, b) = create_matched_datasets(
        data_root_a="ablation_study_data/trashnet_small",
        data_root_b="ablation_study_data/realwaste_small",
        split_ratio=(0.7, 0.15, 0.15), img_size=args.img_size, seed=args.seed,
    )
    train_set, val_set, test_set, classes, split_path = a if args.dataset_name == "trashnet" else b

其余训练循环、模型构建、checkpoint 保存逻辑完全不用动。为避免覆盖已有
checkpoint，建议把保存路径加上 "_matched" 后缀（如
`best_escnn_C8_trashnet_matched.pth`），train_d4_resnet18.py /
escnn_train_v3_so2.py / escnn_v5_so2.py 同理。

本次代码交付里，`train_ablation_matched.py` 已经把这两行改动完整做好，
可以直接跑，作为 R1-#1 最核心也是最快能拿到结果的一行证据
（ResNet-18 baseline 的 TN→RW / RW→TN 不对称性在类别数量匹配后是否消失）。
如果想要全部 5 个架构的匹配结果，请按上面的模式对其余 4 个脚本各改 2 行。
"""
