"""
train_ablation_augmented.py
=============================

Reviewer 1, Concern #8 ("R1-#8")：给 ResNet-18 基线加上旋转 + 翻转数据增强，
看它能否追平甚至超过 C4/C8/D4 等变网络。

设计要点
--------
- 复用与 Table 6（`train_ablation.py`）**完全相同**的 5 类子集
  （`ablation_study_data/{trashnet_small,realwaste_small}`）与**完全相同**的
  train/val/test 划分（直接读取已存在的 `splits/{trashnet_small,realwaste_small}
  _split.json`，通过 `dataset.py::create_trashnet_datasets` 拿到），只把训练集的
  数据增强换成：
      RandomRotation(360°，任意角度，双线性插值，边缘用反射填充避免黑边)
      + RandomHorizontalFlip(p=0.5) + RandomVerticalFlip(p=0.5)
  （原始 `dataset.py::_build_transforms` 的注释里明确写着"不做随机旋转（与旋转
  等变网络对比更公平）"——这正是 R1-#8 要打破的那个对照，因此这里特意单独写
  一份增强版 transform，不去改动 `dataset.py`，以免影响其余所有实验的可比性。）
- 训练超参数（优化器 SGD、lr/batch/epochs/scheduler）与 `train_ablation.py`
  保持逐项一致，只有数据增强不同，这样"是否加旋转增强"就是唯一的自变量，
  结果可以和 Table 6 现有 ResNet-18 行做严格的单变量对比。
- val/test 仍使用原始（无旋转增强）的 eval transform，与其余所有实验一致
  （评估阶段不做随机增强是标准实践，也保证和其它探针的评估条件完全对齐）。

用法：
    python train_ablation_augmented.py --dataset-name trashnet  --epochs 100 --batch-size 32
    python train_ablation_augmented.py --dataset-name realwaste --epochs 100 --batch-size 32

产出：
    checkpoints/best_resnet18_ablation_{dataset}_augmented.pth
    logs/train_ablation_{dataset}_augmented_log.csv

训练完成后，用与 ablation_matched_cross_eval.py 相同的思路做跨域评估即可
（见文末 `ablation_augmented_cross_eval.py` 调用说明）——本文件底部已经附带
一个可直接运行的跨域评估函数，用法见 `--cross-eval` 开关。
"""

import os
import csv
import time
import argparse
from typing import Tuple, List

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset, Dataset
from torchvision import models, datasets, transforms

from dataset import create_trashnet_datasets

DATASET_ROOTS = {
    "trashnet": "ablation_study_data/trashnet_small",
    "realwaste": "ablation_study_data/realwaste_small",
}
OTHER_DOMAIN_ROOT = {
    "trashnet": "ablation_study_data/realwaste_small",
    "realwaste": "ablation_study_data/trashnet_small",
}
TEST_CLASSES = ["cardboard", "glass", "metal", "paper", "plastic"]


def build_resnet18(num_classes: int, pretrained: bool = False) -> nn.Module:
    try:
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
    except AttributeError:
        model = models.resnet18(pretrained=pretrained)
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model


def _build_augmented_train_transform(img_size: int) -> transforms.Compose:
    norm_mean = [0.485, 0.456, 0.406]
    norm_std = [0.229, 0.224, 0.225]
    return transforms.Compose([
        transforms.RandomResizedCrop(img_size, scale=(0.8, 1.0)),
        transforms.RandomRotation(degrees=360, interpolation=transforms.InterpolationMode.BILINEAR,
                                   expand=False, fill=0),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),
        transforms.ToTensor(),
        transforms.Normalize(mean=norm_mean, std=norm_std),
    ])


def make_augmented_train_set(data_root: str, img_size: int, seed: int) -> Tuple[Subset, List[str]]:
    """
    复用 create_trashnet_datasets 已经写好/缓存的 70/15/15 划分索引（保证与
    Table 6 的 train/val/test 完全一致），只替换训练集使用的 transform。
    """
    train_set, _val_set, _test_set, classes, _split_path = create_trashnet_datasets(
        data_root=data_root, split_ratio=(0.7, 0.15, 0.15), img_size=img_size, seed=seed,
    )
    aug_tf = _build_augmented_train_transform(img_size)
    train_full_aug = datasets.ImageFolder(root=data_root, transform=aug_tf)
    # train_set 是 Subset(ImageFolder(...), indices)；索引在同一份底层 samples 列表上有效，
    # 因为 ImageFolder 对同一目录的 samples 顺序是确定性的（按文件系统扫描 + 排序）。
    augmented_train_set = Subset(train_full_aug, train_set.indices)
    return augmented_train_set, classes


def accuracy_top1(logits: torch.Tensor, targets: torch.Tensor) -> float:
    return (logits.argmax(dim=1) == targets).sum().item() / targets.size(0)


def average_precision(scores: torch.Tensor, labels: torch.Tensor) -> float:
    n_pos = labels.sum().item()
    if n_pos == 0:
        return 0.0
    order = torch.argsort(scores, descending=True)
    y = labels[order]
    tp = torch.cumsum(y, dim=0).float()
    fp = torch.cumsum(1 - y, dim=0).float()
    precision = tp / torch.clamp(tp + fp, min=1.0)
    recall = tp / float(n_pos)
    for i in range(precision.numel() - 2, -1, -1):
        if precision[i] < precision[i + 1]:
            precision[i] = precision[i + 1]
    r = torch.cat([torch.zeros(1), recall, torch.ones(1)])
    p = torch.cat([torch.tensor([precision[0].item()]), precision, torch.tensor([0.0])])
    return float(torch.sum((r[1:] - r[:-1]) * p[1:]).item())


def compute_map(logits: torch.Tensor, targets: torch.Tensor) -> Tuple[float, List[float]]:
    c = logits.size(1)
    probs = torch.softmax(logits, dim=1)
    aps = [average_precision(probs[:, i], (targets == i).to(torch.int64)) for i in range(c)]
    mAP = float(sum(aps) / len(aps)) if aps else 0.0
    return mAP, aps


def train_one_epoch(model, loader, criterion, optimizer, device) -> Tuple[float, float]:
    model.train()
    running_loss, running_correct, total = 0.0, 0, 0
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, targets)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * targets.size(0)
        running_correct += (logits.argmax(dim=1) == targets).sum().item()
        total += targets.size(0)
    return running_loss / max(1, total), running_correct / max(1, total)


@torch.no_grad()
def evaluate(model, loader, device) -> Tuple[float, float]:
    model.eval()
    all_logits, all_targets = [], []
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        logits = model(images)
        all_logits.append(logits.cpu())
        all_targets.append(targets.cpu())
    logits = torch.cat(all_logits, dim=0)
    targets = torch.cat(all_targets, dim=0)
    acc = accuracy_top1(logits, targets)
    mAP, _ = compute_map(logits, targets)
    return acc, mAP


class FilteredDataset(Dataset):
    def __init__(self, base: datasets.ImageFolder, keep_targets: set, remap: dict):
        self.base = base
        self.indices = [i for i, (_, t) in enumerate(base.samples) if t in keep_targets]
        self.remap = remap

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        x, t_base = self.base[self.indices[idx]]
        return x, self.remap[t_base]


def get_eval_transform(img_size: int):
    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    return transforms.Compose([
        transforms.Resize(int(img_size * 1.14)),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])


def cross_eval(model, model_classes, target_root, img_size, device):
    if not os.path.isdir(target_root):
        print(f"[跳过跨域评估] 找不到 {target_root}")
        return None
    tf = get_eval_transform(img_size)
    base = datasets.ImageFolder(root=target_root, transform=tf)
    name_lower = {c.lower(): c for c in base.classes}
    present = [c for c in TEST_CLASSES if c in name_lower]
    keep_targets = {base.class_to_idx[name_lower[c]] for c in present}
    remap = {base.class_to_idx[name_lower[c]]: i for i, c in enumerate(present)}
    ds = FilteredDataset(base, keep_targets, remap)
    loader = DataLoader(ds, batch_size=32, shuffle=False, num_workers=0, pin_memory=True)
    order_to_index = {name: i for i, name in enumerate(model_classes)}
    model_cols = [order_to_index[c] for c in present if c in order_to_index]
    all_logits, all_targets = [], []
    with torch.no_grad():
        for images, targets in loader:
            images = images.to(device, non_blocking=True)
            logits = model(images)[:, model_cols].cpu()
            all_logits.append(logits)
            all_targets.append(targets.cpu())
    logits = torch.cat(all_logits, dim=0)
    targets = torch.cat(all_targets, dim=0)
    acc = accuracy_top1(logits, targets)
    mAP, _ = compute_map(logits, targets)
    return {"acc": acc, "mAP": mAP, "n_samples": int(logits.size(0))}


def main():
    parser = argparse.ArgumentParser(description="旋转+翻转数据增强 ResNet18 消融训练 (R1-#8)")
    parser.add_argument("--dataset-name", type=str, required=True, choices=["trashnet", "realwaste"])
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--momentum", type=float, default=0.9)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--img-size", type=int, default=224)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument("--cross-eval", action="store_true",
                         help="训练结束后立即对另一个域做跨域评估，结果追加到日志末尾")
    args = parser.parse_args()

    os.makedirs("checkpoints", exist_ok=True)
    os.makedirs("logs", exist_ok=True)

    data_root = DATASET_ROOTS[args.dataset_name]
    train_set, classes = make_augmented_train_set(data_root, args.img_size, args.seed)
    # val/test 沿用未增强的原始划分，保证评估条件与 Table 6 完全一致
    _train_plain, val_set, test_set, _classes2, split_path = create_trashnet_datasets(
        data_root=data_root, split_ratio=(0.7, 0.15, 0.15), img_size=args.img_size, seed=args.seed,
    )
    print(f"[增强版数据集] {args.dataset_name} -> classes={classes}, "
          f"train/val/test={len(train_set)}/{len(val_set)}/{len(test_set)}, split={split_path}")
    print("[训练增强] RandomResizedCrop + RandomRotation(360°) + RandomHFlip + RandomVFlip")

    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True,
                               num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False,
                             num_workers=args.num_workers, pin_memory=True)
    test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False,
                              num_workers=args.num_workers, pin_memory=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_resnet18(num_classes=len(classes), pretrained=args.pretrained).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=max(1, args.epochs // 3), gamma=0.1)

    log_file = os.path.join("logs", f"train_ablation_{args.dataset_name}_augmented_log.csv")
    with open(log_file, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(["epoch", "train_loss", "train_acc", "val_acc", "val_mAP", "lr"])

    best_val_acc = 0.0
    start_time = time.time()
    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_acc, val_map = evaluate(model, val_loader, device)
        scheduler.step()
        with open(log_file, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([epoch, f"{train_loss:.6f}", f"{train_acc:.4f}", f"{val_acc:.4f}",
                                     f"{val_map:.4f}", f"{scheduler.get_last_lr()[0]:.6f}"])
        print(f"Epoch {epoch:02d} | train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
              f"val_acc={val_acc:.4f} val_mAP={val_map:.4f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            ckpt_path = os.path.join("checkpoints", f"best_resnet18_ablation_{args.dataset_name}_augmented.pth")
            torch.save({
                "epoch": epoch, "model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                "val_acc": val_acc, "val_mAP": val_map, "classes": classes,
                "pretrained": args.pretrained, "augmented": True,
            }, ckpt_path)
            print(f"已保存最佳模型到: {ckpt_path}")

    print(f"训练完成，总耗时 {(time.time() - start_time)/60:.1f} 分钟")
    test_acc, test_map = evaluate(model, test_loader, device)
    print(f"[Test] top1_acc={test_acc:.4f} mAP={test_map:.4f}")
    with open(log_file, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(["test", "", "", f"{test_acc:.4f}", f"{test_map:.4f}", ""])

    if args.cross_eval:
        other_root = OTHER_DOMAIN_ROOT[args.dataset_name]
        res = cross_eval(model, [c.lower() for c in classes], other_root, args.img_size, device)
        if res is not None:
            direction = "TN->RW" if args.dataset_name == "trashnet" else "RW->TN"
            print(f"[跨域评估 {direction}] acc={res['acc']:.4f} mAP={res['mAP']:.4f} (n={res['n_samples']})")
            with open(log_file, "a", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow([f"cross_{direction}", "", "", f"{res['acc']:.4f}", f"{res['mAP']:.4f}", ""])


if __name__ == "__main__":
    main()
